package com.scrappers.notepadsnippet;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.github.clans.fab.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.douglasjunior.androidSimpleTooltip.ArrowDrawable;
import io.github.douglasjunior.androidSimpleTooltip.SimpleTooltip;
import jp.wasabeef.richeditor.RichEditor;

import static android.os.Environment.getExternalStorageDirectory;
import static android.view.View.SCROLL_INDICATOR_BOTTOM;
import static android.view.View.TEXT_DIRECTION_LOCALE;
import static android.view.View.TEXT_DIRECTION_RTL;
import static android.webkit.WebSettings.ZoomDensity;
import static com.scrappers.notepadsnippet.MainActivity.DISABLE_FINGERPRINT;
import static com.scrappers.notepadsnippet.MainActivity.NoMoreTutorials;
import static com.scrappers.notepadsnippet.MainActivity.NumberofNotes;
import static com.scrappers.notepadsnippet.MainActivity.Theme;
import static com.scrappers.notepadsnippet.MainActivity.fileName;
import static com.scrappers.notepadsnippet.MainActivity.finalOutText;
import static com.scrappers.notepadsnippet.MainActivity.recordName;
import static com.scrappers.notepadsnippet.MainActivity.triggerEdit;
import static com.scrappers.notepadsnippet.Slider.firstStart;


interface EditPaneActivityUI{
    void prepare_For_the_note_options();
    void vibrator(Vibrator v);
    void InfinteCheckForPLayPauseBTN();
    void writeTextFiles(String path,String data);
    void DialogBoxWithRecordSave();
    void DialogBoxWithoutRecordSave();
    void AccessMicPermissions();
    void DefineNewRecord(String path);
    void RefreshRecordingValues();
    void stopRecording();
    void getDurationOfPlayMedia();
    void getCurrentProgressOfPlayMedia();
    void Handle_Record_Duration();
    void DefineExistingRecording(String path);
    void hideRecordComponent();
    void showRecordComponent();
    void shareRecord(String path);
    void shareNoteTXT();
    void SpeakOut();
    void update();
    void showMediaComponents();
    void getDurationOfPlayMedia_ForShowMediaUpdate();
    void hideMediaComponents();
}

interface Btn_ClickListeners{

    void RecordBtn(View view);
    void playRecordingOrPause(View view);
    void playRecordPauseBtn(View view);
    void PauseRecordBtn(View view);
    void savebtnAction(View view);
    void shareActionBtn(View view);
    void searchWordBtn(View view);
    void Listener_For_TextColor(View view);
    void Listener_For_SpanColor(View view);
    void Delete_Record(View view);


}


public  class EditPaneActivity extends AppCompatActivity implements EditPaneActivityUI,
                                                                    Btn_ClickListeners {



    //Instances(Components Objects)
    public static RichEditor ed;
    public EditText ed1;
    public TextView Duration;
    public TextView CurrentPositionOfMedia;
    FloatingActionButton playPause;
    static FloatingActionButton recordStop;
    FloatingActionButton pasueRecord;
    FloatingActionButton speakBtn;
    SeekBar MediaSeekbar;
    AlertDialog d;

    //tts Engine attributes
    public TextToSpeech ttsEngine;
    public PendingIntent pendingIntent;
    static MediaRecorder record;
    MediaPlayer playRecord;

    //Reference Points
    public int SPEAK_STATE = 0;
    public static int VALUE_OF_RECORD = 1;
    public int PAUSE_VALUE = 1;

    boolean stopSimulate = false;

    String text = null;
    public static String pathForRecordings;
    public static String NewFileName;
    public static String path;
    public static boolean okPressed = false;
    String spancolor = "FFF000", textcolor;
    boolean recordingNow = false;

    //..............................................................................................
    static String handleRecordText_Notification = null;
    static int recordSeconds = 0;
    static int recordMinutes = 0;
    static int recordHours = 0;
    static Handler handlerForRecordDuration = new Handler();
    static TextView record_duration_txt;
    static String recordHoursString;
    static String recordMinutesString;
    static String recordSecondsString;
    //Handle the Progression of the SeekBar in a runOnUiThread >>>
    public Handler handler = new Handler();
    boolean btnBack = false;

    //unsaved todolist data parsed from the todo_list activty class(Dialog Box)
    public static String New_UnSaved_TodoList_Strings = "";
    String path_For_Todo_List;
    int recorded_for_first_time=0;
    boolean deleted=false;

    int fontsize=4;

    //Color panel Fragment Related
    int SHOW_COLOR_PANEL = 0;
    public static String COLOR_PANEL_FOR="";
    //relatd to the trackBall
//    int motion=1;

    AlertDialog navbar;

    public static boolean high_quality;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //read theme & Apply it
        ReadTheme();
        super.onCreate(savedInstanceState);
        //set layout view
        setContentView(R.layout.activity_edit_pane);
        //Disable fingerprint assigned to true to dsiale it on this activity exit
        DISABLE_FINGERPRINT=true;
        //progress Dialog to wait for loading components in layout activity_edit_pane
        final ProgressDialog progress= ProgressDialog.show(this,"Wait...","Loading Note Workspace");
        //countDown Timer to Dismiss that dialog and load the components after 1200 ms w/ a countDown=100ms each time
        CountDownTimer ctd=new CountDownTimer(650,100) {
            @Override
            public void onTick(long millisUntilFinished) { }

            @Override
            public void onFinish() {
                //prepare for the options available
                prepare_For_the_note_options();
                //setting up the RichEditor preferences -> B/I/U/Undo/Redo/etc
                textFormatChanger();
                //open nav bar
                open_Nav_Bar_listener();
                //Access the Mic Permissions
                AccessMicPermissions();
                //progress dialog dismiss after components load up
                progress.dismiss();
                if ( firstStart ){
                    showToolTipWindow(findViewById(R.id.edText), ArrowDrawable.LEFT, "Write Notes here");
                }

            }
        }.start();



    }
    int shift=0;

    public SimpleTooltip.Builder showToolTipWindow(View view, int ArrowDirection, String message) {
        if ( NoMoreTutorials ){
            SimpleTooltip.Builder tooltip = new SimpleTooltip.Builder(this);
            if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ){
                tooltip.anchorView(view)
                        .text(message)
                        .gravity(Gravity.END)
                        .arrowDirection(ArrowDirection)
                        .dismissOnOutsideTouch(true)
                        .animated(true)
                        .arrowColor(getResources().getColor(R.color.fab_red_color))
                        .transparentOverlay(false)
                        .textColor(getColor(R.color.white))
                        .backgroundColor(getResources().getColor(R.color.fab_red_color))
                        .onDismissListener(new SimpleTooltip.OnDismissListener() {
                            @Override
                            public void onDismiss(SimpleTooltip tooltip) {
                                tooltip.dismiss();
                                ++shift;
                                switch (shift) {
                                    case 1:
                                        tooltip.dismiss();
                                        showToolTipWindow(findViewById(R.id.menu), ArrowDrawable.RIGHT, "More Options");
                                        break;
                                    case 2:
                                        tooltip.dismiss();
                                        showToolTipWindow(findViewById(R.id.openNavBarBtn), ArrowDrawable.RIGHT, "Hold & Swipe Right \n" +
                                                "Speak note,TodoList,Paint,OCR\n");

                                        break;
                                    case 3:
                                        tooltip.dismiss();
                                        showToolTipWindow(findViewById(R.id.bottomBarLayout), ArrowDrawable.LEFT, "Customize Your Text");
                                        NoMoreTutorials = false;
                                        break;
                                    default:
                                        tooltip.dismiss();
                                        break;
                                }
                            }
                        })
                        .build()
                        .show();
            }
            return tooltip;

        } else {
            return null;
        }
    }

    //Method to config the RichEditor preferences + action Listeners of their buttons
    public void textFormatChanger(){



        //adjust the webSettings for the richEditor
        final WebSettings webJS=ed.getSettings();

        webJS.setJavaScriptEnabled(true);
        webJS.setAllowFileAccess(true);
        webJS.setDisplayZoomControls(false);
        webJS.setAllowContentAccess(true);
        webJS.setBuiltInZoomControls(true);
        webJS.setEnableSmoothTransition(true);
        webJS.setLoadsImagesAutomatically(true);
        webJS.setDefaultZoom(ZoomDensity.FAR);
        ed.setTextDirection(TEXT_DIRECTION_LOCALE);


        ed.setEditorFontSize(20);
        ed.setFontSize(7);

        ed.setTextBackgroundColor(getResources().getColor(R.color.transparent));
        ed.setTextColor(getResources().getColor(R.color.text_black));
        ed.setPlaceholder("Type Here...");

            //check for themes & apply different preferences
            if ( Theme.contains("GrayScaleTheme") || Theme.contains("CyanTheme") ){
                ed.setEditorFontColor(Color.WHITE);
                ed.setEditorWidth(22);
                ed.setBackgroundColor(getResources().getColor(R.color.colorAccent));
            } else if ( Theme.contains("AppTheme") ){
                ed.setBackgroundColor(getResources().getColor(R.color.cornysilk));
            } else if ( Theme.contains("GreenTheme") ){
                ed.setBackgroundColor(getResources().getColor(R.color.fade_white));
            }else if(Theme.length()<=0){
                ed.setBackgroundColor(getResources().getColor(R.color.cornysilk));
            }


        //Button Listeners -->>
        findViewById(R.id.action_undo).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.undo();
            }
        });

        findViewById(R.id.action_redo).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.redo();
            }
        });

        findViewById(R.id.action_bold).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setBold();

            }
        });

        findViewById(R.id.action_italic).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setItalic();

            }
        });

        findViewById(R.id.action_subscript).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setSubscript();

            }
        });

        findViewById(R.id.action_superscript).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setSuperscript();

            }
        });

        findViewById(R.id.action_strikethrough).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setStrikeThrough();

            }
        });

        findViewById(R.id.action_underline).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setUnderline();

            }
        });


        findViewById(R.id.size_up).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setFontSize((fontsize>=7)?fontsize=7:(fontsize+=1));

            }
        });

        findViewById(R.id.size_down).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {

                ed.setFontSize((fontsize<=1)?fontsize=1:(fontsize-=1));

            }
        });

        findViewById(R.id.action_txt_color).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display_color_panel_choose();
                COLOR_PANEL_FOR="textcolor";

            }

        });

        findViewById(R.id.action_bg_color).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display_color_panel_choose();
                COLOR_PANEL_FOR="highlightcolor";

            }
        });

        findViewById(R.id.action_indent).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setIndent();

            }
        });

        findViewById(R.id.action_outdent).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setOutdent();

            }
        });

        findViewById(R.id.action_align_left).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setAlignLeft();

            }
        });

        findViewById(R.id.action_align_center).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setAlignCenter();

            }
        });

        findViewById(R.id.action_align_right).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setAlignRight();

            }
        });

        findViewById(R.id.action_blockquote).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setBlockquote();

            }
        });

        findViewById(R.id.action_insert_bullets).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setBullets();

            }
        });

        findViewById(R.id.action_insert_numbers).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ed.setNumbers();
            }
        });

        findViewById(R.id.action_insert_image).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                //focus editor before fetching image from file directory
                ed.focusEditor();
                //new Intent instance of the ACTION_OPEN_DOCUMENT parameter
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                //setting type of file displayed there
                intent.setType("image/*");
                //setting intent category Type -> Openable Means it opens the file manager & its defaultly Applied
                //in case of the ACTION_OPEN_DOCUMENT intent
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                //starting the activity w/ a result listener & an id"Request Code" = 2020
                startActivityForResult(Intent.createChooser(intent, "Choose the file to Upload.."),
                        2020);
            }
        });

        findViewById(R.id.insert_fromStorage).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/*");
                startActivityForResult(intent,
                        3030);

            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    static FrameLayout frameLayout;
    public void display_color_panel_choose(){
         frameLayout = findViewById(R.id.colorPanelChooser);
        //Fragment & FragmentTransaction
        ColorPanel panel = new ColorPanel();
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
//        fm.setCustomAnimations(R.anim.fab_slide_in_from_left,R.anim.fab_slide_in_from_right);
        //show the current fragment in that frameLayout Container
        fm.replace(R.id.colorPanelChooser, panel);
        //apply Changes
        fm.commit();


            frameLayout.setVisibility(View.INVISIBLE);


        switch (frameLayout.getVisibility()) {
            case View.INVISIBLE:
                //show fragment control buttons on
                frameLayout.setVisibility(View.VISIBLE);
                frameLayout.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_up));
                break;

            case View.VISIBLE:
                frameLayout.setVisibility(View.INVISIBLE);
                frameLayout.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_down));
                break;
            case View.GONE:
                break;
        }
    }

    //Activity Request Listener for handling the open of ACTION_OPEN_DOCUMENT Intent
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ( requestCode == 2020 ){
            //Image Scaling related ->>>>

            try {
                //Inset img as <img> html tag vi the RichEditor
                ed.insertImage(data.getDataString(),
                        "");


            } catch (Exception error1) {
                error1.printStackTrace();
                Toast.makeText(getApplicationContext(), "No images ve been chosen", Toast.LENGTH_SHORT).show();
            }

        }else if(requestCode == 3030){
            String path=data.getData().getPath();
            assert path != null;
            path=path.substring(path.indexOf(":")+1);
            ed.setHtml((ed.getHtml()==null?"":ed.getHtml())+"\n"+"  "+ readString(path)+"\n");
        }
    }

    private String readString(String file) {
        String data="";
        try{
            BufferedReader reader=new BufferedReader(new FileReader(new File(getExternalStorageDirectory(),file)));
            data=reader.readLine()+"\n";
            while(reader.ready()){
                data+=reader.readLine()+"\n";
            }
        }catch (Exception e){
            e.printStackTrace();

        }
        return data;
    }


    //method to open the  Nav Bar from the Side of the Screen
    public void open_Nav_Bar_listener(){

        //defining a new ImageView instance w/ an id
        final FloatingActionButton openNaveBarBtn=findViewById(R.id.openNavBarBtn);

        //Purpose of Touch Listener inside a Long Click listsner to perform  a long click followed by a little motion to open the Nav bar
        openNaveBarBtn.setOnClickListener(v -> openNavBar());


    }

    //nav bar and its listener
    public void openNavBar(){
        //Dialog builder & its layout Inflater & its Listener
        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);
        final LayoutInflater inflater = this.getLayoutInflater();
        //side_bar_menu XML layout code inflated
        final View layout = inflater.inflate(R.layout.side_bar_menu, null);
        //Define ImageViews Buttons id from that infalted Layout
        ImageView close = layout.findViewById(R.id.closeNav);
        ImageView speakNav = layout.findViewById(R.id.speakNav);
        ImageView todo = layout.findViewById(R.id.todoNav);
        ImageView painter = layout.findViewById(R.id.painterNav);
        ImageView ocr = layout.findViewById(R.id.ocrNav);
        //setting the layout to the view of the AlertDialog
        builder.setView(layout);


//        //buttons click Listeners
        close.setOnClickListener(v -> {
            //closing the dialog on click on the close btn
            navbar.dismiss();
        });
        speakNav.setOnClickListener(new TxtToSpeechbtnAction(getApplicationContext()));
        todo.setOnClickListener(v -> open_todo_list());
        painter.setOnClickListener(v -> {
            if ( triggerEdit == 1 ){
                startActivity(new Intent(getApplicationContext(), com.scrappers.notepadsnippet.Paint.class));
            } else if ( triggerEdit == 0 ){
                Toast.makeText(getApplicationContext(), "Please Save the note first via save button !", Toast.LENGTH_LONG).show();

                DialogBoxWithoutRecordSave();
            }
        });


        ocr.setOnClickListener(v -> Toast.makeText(getApplicationContext(),"OCR Feature: Coming up in a new Update !",Toast.LENGTH_LONG).show());

        //by doing this , you can cancel that dialog by pressing on the blacklite space outside its Design borders
        builder.setCancelable(true);
        //create it
        navbar = builder.create();
        //Dialog background ,by doing this you are making the background as a blacklight space(The Versa is the dimmed background)
        navbar.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        //Dialog gravity
        navbar.getWindow().setGravity(Gravity.BOTTOM);
        navbar.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);
        //dialog animtion
        navbar.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation4;
        //show that button w/ an animation
        navbar.show();
    }
     static ArrayList<String> listTodos=new ArrayList<>();


    public void readTodoList(String file) {
        try {
            listTodos.clear();
            File files[] = new File(file).listFiles();
            for (int numoffiles = 0; numoffiles <= files.length - 1; numoffiles++) {
                listTodos.add(files[numoffiles].getName());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    TodoNote_Adapter todoadapter;
    //Method for todolist
    public void open_todo_list(){

        //Dialog builder & its layout Inflater & its Listener
        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);
        final LayoutInflater inflater = this.getLayoutInflater();
        //side_bar_menu XML layout code inflated
        final View layout = inflater.inflate(R.layout.activity_todo__list_, null);


        //setting the layout to the view of the AlertDialog
        builder.setView(layout);



        RecyclerView rv=layout.findViewById(R.id.TodoList_Grid);
        if(triggerEdit == 1){
            readTodoList(getApplicationContext().getFilesDir() + "/SPRecordings/todoLists/" + fileName);
            todoadapter=new TodoNote_Adapter(listTodos);
            rv.setAdapter(todoadapter);
            rv.setLayoutManager(new LinearLayoutManager(this));



            EditText editView=layout.findViewById(R.id.todoName);
            Button addnote=layout.findViewById(R.id.addtodo);
            //adding new todo note
            addnote.setOnClickListener(v -> {

                saveTodoNote(editView.getText().toString());
                listTodos.add(editView.getText().toString());

                todoadapter.notifyDataSetChanged();
                editView.setText("");

            });

            ImageButton closeTodoWindow=layout.findViewById(R.id.close_todo);
            closeTodoWindow.setOnClickListener(v -> d.dismiss());

            ImageButton removeTodo=layout.findViewById(R.id.remove_all);
            removeTodo.setOnClickListener(v -> {
                File file=new File(App.getContext().getFilesDir() +  "/SPRecordings/todoLists/"+fileName+"/");
                //delete all files in the path individually
                File files[]=file.listFiles();
                for (File value : files) {
                    //remove each file(resembles todo note ) individually
                    value.delete();
                }
                //remove data from adapter and clear it
                listTodos.clear();
                //apply the changes to the adapter
                todoadapter.notifyDataSetChanged();
                Snackbar.make(layout,fileName+" TodoList is deleted Successfully",Snackbar.LENGTH_LONG).show();
            });




            //by doing this , you can cancel that dialog by pressing on the blacklight space outside its Design borders
            builder.setCancelable(true);
            //create it
            d = builder.create();
            //Dialog background ,by doing this you are making the background as a blacklight space(The Versa is the dimmed background)
            d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            //Dialog gravity
            d.getWindow().setGravity(Gravity.CENTER);
            //dialog animtion
            d.getWindow().getAttributes().windowAnimations = R.style.Scale;
            d.setCancelable(false);
            //show that button w/ an animation
            d.show();

        }else if(triggerEdit == 0){

            Toast.makeText(getApplicationContext(),"Please Save the note first via save button !",Toast.LENGTH_LONG).show();

            DialogBoxWithoutRecordSave();

        }




    }

    public static class DeleteTodoListCLass implements View.OnClickListener {
        RecyclerView.Adapter adapter;
        int position;
        DeleteTodoListCLass(RecyclerView.Adapter adapter, int position){
            this.adapter=adapter;
            this.position=position;
        }
        @Override
        public void onClick(View v) {
            removeFile(App.getContext().getFilesDir() +  "/SPRecordings/todoLists/"+fileName+"/"+listTodos.get(position));
            listTodos.remove(position);
            adapter.notifyDataSetChanged();

        }

        private void removeFile(String s) {
            File file=new File(s);
            file.delete();
        }
    }

    public void saveTodoNote(String note){
        File dir=new File(getFilesDir() +  "/SPRecordings/todoLists/"+fileName);
        dir.mkdir();
        try {
            BufferedWriter write=new BufferedWriter(new FileWriter(dir+"/"+note));
            write.write("false");
            write.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void prepare_For_the_note_options(){
        if ( triggerEdit == 1 ){
            ed = findViewById(R.id.edText);
            ed.setHtml(finalOutText);
            DefineExistingRecording(recordName);

        } else {
            ed = findViewById(R.id.edText);


            FloatingActionButton fb=findViewById(R.id.deleteRecord);
            fb.setEnabled(false);

            FloatingActionButton fb2=findViewById(R.id.playPause);
            fb2.setEnabled(false);

            FloatingActionButton fb3=findViewById(R.id.PauseRecord);
            fb3.setEnabled(false);
        }


        //Make New directory for recordings
        File ReordingsFile = new File(getExternalStorageDirectory() + "/" + "SPRecordings");
        ReordingsFile.mkdir();


    }


    public void ReadTheme(){
        //applying themes according to the content
        if(Theme.contains("GreenTheme")){
            setTheme(R.style.GreenTheme);
        }else if(Theme.contains("AppTheme")){
            setTheme(R.style.AppTheme);
        }else if(Theme.contains("GrayScaleTheme")){
            setTheme(R.style.Darky);
        }else if(Theme.contains("TitanTheme")){
            setTheme(R.style.orangeLover);
        }else if(Theme.contains("CyanTheme")){
            setTheme(R.style.BlueDark);
        }
    }


    @Override
    public void InfinteCheckForPLayPauseBTN() {
        //Using an action listener
        try {
            playRecord.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {


                    playPause.setLabelText("Play Record Again");

                    Drawable img = getApplicationContext().getResources().getDrawable(R.drawable.play_ico);
                    playPause.setImageDrawable(img);

                    stopSimulate = false;

                }
            });

        } catch (Exception error) {
//            Toast.makeText(getApplicationContext(), "No Record to declare !", Toast.LENGTH_LONG).show();
            hideMediaComponents();
        }
    }


    //vibration cascade
    @Override
    public void vibrator(Vibrator v) {
        v.vibrate(20);
    }



    public int getScreenWidth(){
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        return size.x;
    }
    public int getScreenHeight(){
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        return size.y;

    }

    @Override
    public void onBackPressed() {
        try {
            stopRecording();
            playRecord.stop();
            playRecord.release();
            //dismiss this callback UI Event Handler
            handler.removeCallbacksAndMessages(null);


        } catch (Exception e) {
            e.printStackTrace();
        }
        btnBack = true;
        DialogBoxWithoutRecordSave();
        okPressed=false;
    }


    //write Text Files to External Storage
    @Override
    public void writeTextFiles(String path, String data) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(path));
            writer.write(data);
//            Toast.makeText(getApplicationContext(), "Save Successful", Toast.LENGTH_LONG).show();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void DialogBoxWithRecordSave() {


        if ( triggerEdit == 0 ){


            AlertDialog.Builder builder =
                    new AlertDialog.Builder(this);
            final LayoutInflater inflater = this.getLayoutInflater();
            final View layout = inflater.inflate(R.layout.dialogboxlayout, null);
            Button okbtn = layout.findViewById(R.id.okBtn);
            Button cancelbtn = layout.findViewById(R.id.CancelBtn);
            builder.setView(layout);
            // Dialog will have "Make a selection" as the title



            okbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ed1 = layout.findViewById(R.id.nameofsavefile);
                    NewFileName = ed1.getText().toString();

                    if ( !NewFileName.isEmpty() ){
                        path = getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + NewFileName;
                        try {
                            writeTextFiles(path, ed.getHtml().toString());

                        }catch (NullPointerException e){
                            e.printStackTrace();
                            writeTextFiles(path, "");

                        }

//                        //if its a new note file(not an open of a previous one) -> Svae for todolists
//                        if ( triggerEdit == 0 ){
//                            path_For_Todo_List = getExternalStorageDirectory() + "/SPRecordings/todoLists/" + NewFileName + ".tdl";
//                            writeTextFiles(path_For_Todo_List, New_UnSaved_TodoList_Strings);
//
//                        }

                        pathForRecordings = getExternalStorageDirectory() + "/SPRecordings/" + NewFileName
                                + ".mp3";

                        DefineNewRecord(pathForRecordings);
                        okPressed = true;

                        triggerEdit = 1;
                        recorded_for_first_time=1;
                        d.dismiss();

                    } else {

                        path = getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" +"Note "+(NumberofNotes);


                        try {
                            writeTextFiles(path, ed.getHtml().toString());

                        }catch (NullPointerException e){
                            e.printStackTrace();
                            writeTextFiles(path, "");

                        }

                        pathForRecordings = getExternalStorageDirectory() + "/SPRecordings/" + "Note "+(NumberofNotes)+".mp3";

                        DefineNewRecord(pathForRecordings);
                        okPressed = true;

                        triggerEdit=1;
                        recorded_for_first_time=1;
                        d.dismiss();
                    }


                }
            });


            cancelbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    VALUE_OF_RECORD = 1;
                    text="Record";
                    FloatingActionButton recordStop=findViewById(R.id.Recordbtn);
                    recordStop.setLabelText(text);
                    recordStop.setImageDrawable(getDrawable(R.drawable.recordbtn));
                    d.dismiss();
                }
            });


            builder.setCancelable(false);
            d = builder.create();
            d.getWindow().setGravity(Gravity.CENTER);
            d.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation2;


            d.show();


        } else {

            writeTextFiles(getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + fileName, ed.getHtml().toString());

                    pathForRecordings = getExternalStorageDirectory() + "/SPRecordings/" + fileName
                            + ".mp3";
                    DefineNewRecord(pathForRecordings);
                    okPressed = true;


        }
    }






    @Override
    public void DialogBoxWithoutRecordSave() {

        //check if its a new note -> then show a dialog box w/ save name procedure ;_>>
        if ( triggerEdit == 0 ){


            AlertDialog.Builder builder =
                    new AlertDialog.Builder(this);
            final LayoutInflater inflater = this.getLayoutInflater();
            final View layout = inflater.inflate(R.layout.dialogboxlayout, null);
            Button okbtn = layout.findViewById(R.id.okBtn);
            Button cancelbtn = layout.findViewById(R.id.CancelBtn);

            builder.setView(layout);
            // Dialog will have "Make a selection" as the title


            okbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ed1 = layout.findViewById(R.id.nameofsavefile);
                    NewFileName = ed1.getText().toString();
                    if ( !NewFileName.isEmpty() ){
                        path = getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + NewFileName;

                        try {
                            writeTextFiles(path, ed.getHtml().toString());

                        }catch (NullPointerException e){
                            e.printStackTrace();
                            writeTextFiles(path, "");

                        }
                        if ( triggerEdit == 0 ){
                            path_For_Todo_List = getApplicationContext().getFilesDir() + "/SPRecordings/todoLists/" + NewFileName + ".tdl";
                            writeTextFiles(path_For_Todo_List, New_UnSaved_TodoList_Strings);
                        }

                        triggerEdit = 1;

                        d.dismiss();


                        //restart to refresh
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        overridePendingTransition(R.anim.slide_in_left_noalpha,R.anim.slide_out_right_noalpha);
                        finish();


                    } else {
                        path = getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + "Note "+(NumberofNotes);


                        try {
                            writeTextFiles(path, ed.getHtml().toString());

                        }catch (NullPointerException e){
                            e.printStackTrace();
                            writeTextFiles(path, "");

                        }
                        if ( triggerEdit == 0 ){
                            path_For_Todo_List = getApplicationContext().getFilesDir() + "/SPRecordings/todoLists/" + "Note "+(NumberofNotes)+".tdl";
                            writeTextFiles(path_For_Todo_List, New_UnSaved_TodoList_Strings);

                        }

                        triggerEdit=1;
                        d.dismiss();


                        //restart to refresh
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        overridePendingTransition(R.anim.slide_in_left_noalpha,R.anim.slide_out_right_noalpha);
                        finish();
                    }
                }
            });


            cancelbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if ( btnBack == true ){
//                        Toast.makeText(getApplicationContext(), "Note Not Saved !", Toast.LENGTH_LONG).show();
                        d.dismiss();
                        //Back to the MainActivity class
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        overridePendingTransition(R.anim.slide_in_left_noalpha,R.anim.slide_out_right_noalpha);
                        finish();
                        btnBack = false;

                    } else {
//                        Toast.makeText(getApplicationContext(), "Note Not Saved !", Toast.LENGTH_LONG).show();
                        d.dismiss();
                    }
                }
            });

            builder.setCancelable(true);
            d = builder.create();
            d.getWindow().setGravity(Gravity.CENTER);
            d.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation2;
            d.show();


        }else if(triggerEdit==1){

            try {
                writeTextFiles(getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + fileName, ed.getHtml().toString());
//            Toast.makeText(getApplicationContext(), "Note  Saved with the same Name !", Toast.LENGTH_LONG).show();
            }catch (NullPointerException e){
                e.printStackTrace();
                writeTextFiles(getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + fileName, "");

            }

            //restart to refresh
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            overridePendingTransition(R.anim.slide_in_left_noalpha,R.anim.slide_out_right_noalpha);
            finish();


        }

        if(recorded_for_first_time==1){
            try {
                writeTextFiles(getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + NewFileName, ed.getHtml().toString());
//            Toast.makeText(getApplicationContext(), "Note  Saved with the same Name !", Toast.LENGTH_LONG).show();
            }catch (NullPointerException e){
                e.printStackTrace();
                writeTextFiles(getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + NewFileName, "");

            }

            //restart to refresh
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            overridePendingTransition(R.anim.slide_out_activity,R.anim.slide_out_activity);
            finish();
        }

        //to delete the excess null file created by the  DialogBoxWithoutRecordSave(); after pressing back after recording something
        //why it saves an excess file as a null file ..?
        //Because  DialogBoxWithoutRecordSave(); method takes the name written in a dialog box dispalyed when there is
        //susceptible behaviour of user to press the save Note fab btn but in case he didnot as in this case
        //an excess file will be saved as null w/o a record due to using DialogBoxWithoutRecordSave();
        //& w/ the same the text that the last file is saved w/ (which the file w/ the record in this case
        try {
            new File(getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + "null").delete();


        }catch (Exception e){
            e.printStackTrace();
        }

    }





    @Override
    public void AccessMicPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.RECORD_AUDIO},
                11);
    }


    @Override
    public void DefineNewRecord(String recordnameLocal) {

        recordStop = findViewById(R.id.Recordbtn);

        try {
            record = null;
            record = new MediaRecorder();
            record.reset();
            record.setAudioSource(MediaRecorder.AudioSource.MIC);
            //donot use AAC_ADTS & AMR_WB & AMR_NB & anything rather than THREE_GPP  w/ any audioEncoder
            record.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
            record.setOutputFile(recordnameLocal);
            //low quality record

            //assign the boolean high_quality to the key high_quality & get the stored boolean which is true as default
            high_quality=getSharedPreferences("recordstate", Context.MODE_PRIVATE)
                    .getBoolean("high_quality", true);
            //assign the value of the record quality according to the high_quality boolean value HE_ACC is the high Quality while AMR_NB is the low quality
                record.setAudioEncoder(high_quality ? MediaRecorder.AudioEncoder.HE_AAC : MediaRecorder.AudioEncoder.AMR_NB);

        } catch (Exception error) {
            error.printStackTrace();
            Toast.makeText(getApplicationContext(), "Mic Permission Denied", Toast.LENGTH_LONG).show();

        }

        try {
            record.prepare();
        } catch (Exception error) {
            error.printStackTrace();
//            Toast.makeText(getApplicationContext(), "Please use a Simplified Name", Toast.LENGTH_LONG).show();

        }

        try {
            record.start();

            //to refresh values
            RefreshRecordingValues();
            Handle_Record_Duration();

            Toast.makeText(getApplicationContext(), "Start Recording on", Toast.LENGTH_LONG).show();


        } catch (IllegalStateException error) {
            error.printStackTrace();
            Toast.makeText(getApplicationContext(), "Error Mic is Busy", Toast.LENGTH_LONG).show();
            VALUE_OF_RECORD = 1;

        }

    }



    @Override
    public void RefreshRecordingValues(){
        recordSeconds=0;
        recordHours=0;
        recordMinutes=0;
        handleRecordText_Notification=null;

    }

    @Override
    public void stopRecording() {
        try {
            record.stop();
            record.release();
            record = null;
            recordingNow=false;

            DefineExistingRecording(pathForRecordings);
            PAUSE_VALUE = 2;
            pasueRecord.setLabelText("Pause");
            Drawable imgPause = getApplicationContext().getResources().getDrawable(R.drawable.pause_ico);
            pasueRecord.setImageDrawable(imgPause);

            showMediaComponents();


        } catch (Exception e) {
            e.printStackTrace();


        }
    }

    @Override
    public void playRecordingOrPause(View v) {
        InfinteCheckForPLayPauseBTN();
        playPause = findViewById(R.id.playPause);
        MediaSeekbar = findViewById(R.id.MediaSeekBar);
        Duration = findViewById(R.id.Duration);
        CurrentPositionOfMedia = findViewById(R.id.CurrentProgress);
        handlerForRecordDuration.removeCallbacksAndMessages(null);

        if (!deleted){

            if ( recordingNow == false ){
                try {
                    if ( stopSimulate == false ){
                        playRecord.start();
                        update();

                        showMediaComponents();

                        getDurationOfPlayMedia();


                        Snackbar.make(v, "Playing Record", Snackbar.LENGTH_LONG).show();
                        stopSimulate = true;
                        playPause.setLabelText("Pause");

                        Drawable img = getApplicationContext().getResources().getDrawable(R.drawable.pause_ico);
                        playPause.setImageDrawable(img);

                    } else {
                        playRecord.pause();
                        Snackbar.make(v, "Pausing Record play", Snackbar.LENGTH_SHORT).show();
                        stopSimulate = false;
                        playPause.setLabelText("Play");
                        Drawable img = getApplicationContext().getResources().getDrawable(R.drawable.play_ico);
                        playPause.setImageDrawable(img);

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    Snackbar.make(v, "No Record to declare !", Snackbar.LENGTH_LONG).show();
                    hideMediaComponents();

                }
            }
        } else {


            hideMediaComponents();
        }
    }

    @Override
    public void getDurationOfPlayMedia() {
        // get mp3 duration
        long dur = playRecord.getDuration();

        //preRequirements:-
        //Quotient Remainder(The quotient remainder theorem) :
        // R=firstNum-[secondNum*QuotientResult] from the main operation: firstNum= (secondNum * Q )+ R ; where 0 ≤ R < B
        // (NB:QuotientResult must be floored to a wholde number , so if Q=0.0005 then it would be 0 , if Q=2.5 then Q=2 not 3)
        //A= B * Q + R  is the breakdown of any multiplication operation in our life , but usually R is zero so we denoted idiotly as A=B*Q w/o R
        // 1 ms= 1/1,000 sec
        // 1 ms = (1/1,000 sec) / 60 = 1/60,000 mins
        // 1 ms = (1/60,000 mins) /60 = 1/3600,000 hrs
        //equations formulas
        //-->  uint(second) = (duration % (its limit converted from millisecond (60,000 as its the begining of mins))  / Conversion constant(1000 for secs )
        //procedure:-
                //beginning by numbers that would produce zero for the seconds(time below seconds)
            //recall dur = 30 ms -> seconds = (30 % 60,000) = remainder=firstNum-[secondNum*QuotientResult]=30-[60,000*0]= 30 (NB:- QuotientResult=0.0005 floored to 0)
        // -> divide by Conversion constant(1000 in this case) = 30/1000 =0.03 fraction still presist -> variable floored & returns zero
        //these operations will go all the way till we reach the 1 real second

        //when we reach 1 sec
        //recall dur = 1000 ms( 1 real second) -> seconds = (1000 % 60,000)= remainder=firstNum-[secondNum*QuotientResult]=1000-[60,000*0]= 1000 (NB:- QuotientResult=0.016666 floored to 0)
        // -> divide by Conversion constant(1000 in this case) = 1000/1000 = 1 now the value is 1 so 1 will be presented in seconds
        //these operations will go all the way till we reach the 2 real seconds


        //when we reach 2 secs
        //recall dur = 2000 ms( 2 real seconds) -> seconds = (2000 % 60,000)= remainder=firstNum-[secondNum*QuotientResult]=2000-[60,000*0]= 2000 (NB:- QuotientResult=0.0333333 floored to 0)
        // -> divide by Conversion constant(1000 in this case) = 2000/1000 = 2 now the value is 2 so 2 will be presented in seconds
        //these operations will go all the way till we reach the 3 real seconds


        //when we reach 22 secs
        //recall dur = 22,000 ms( 22 real seconds) -> seconds = (22,000 % 60,000)= remainder=firstNum-[secondNum*QuotientResult]=22,000-[60,000*0]=22,000  (NB:- QuotientResult=0.3666666 floored to 0)
        // -> divide by Conversion constant(1000 in this case) = 22,000/1000 = 22 now the value is 22 so 22 will be presented in seconds
        //these operations will go all the way till we reach the 60 real seconds

        //when we reach 60 secs
        //recall dur = 60,000 ms( 60 real seconds) -> seconds = (60,000 % 60,000)= remainder=firstNum-[secondNum*QuotientResult]=60,000-[60,000*1]= 0 (NB:- QuotientResult=60,000/60,000 = 1 )
        // -> divide by Conversion constant(1000 in this case) = 0/1000 = 0 now the value is 0 so 0 will be presented in seconds
        //then mins counter starts counting



        //when we reach above 60 secs(in mins)
        //recall dur = 61,000 ms( 61 real seconds) -> seconds = (61,000 % 60,000)= remainder=firstNum-[secondNum*QuotientResult]=61,000-[60,000*1]= 1,000 (NB:- QuotientResult=1.016666 floored to 1 )
        // -> divide by Conversion constant(1000 in this case) = 1,000/1000 = 1 now the value is 1 so 1 will be presented in seconds  as the time now is 01 mins : 01 secs
        //then mins counter continue counting

        //as for mins 61,000 % 3600,000=remainder=firstNum-[secondNum*QuotientResult]=61,000-[3600,000*0]= 61,000


        //when we reach above 60 secs(in mins)
        //recall dur = 70,000 ms( 60 real seconds) -> seconds = (70,000 % 60,000)= remainder=firstNum-[secondNum*QuotientResult]=70,000-[60,000*1]= 10,000 (NB:- QuotientResult=1.16666 floored to 1 )
        // -> divide by Conversion constant(1000 in this case) = 10,000/1000 = 10 now the value is 10 so 10 will be presented in seconds  as the time now is 01 mins : 10 secs
        //then mins counter continue counting

        String seconds = String.valueOf((dur % 60000) / 1000);
        //-->  uint(minutes) = (duration % (its limit converted from millisecond  (3600,000 as its the begining of hrs))  / Conversion constant(60,000 for mins )
        String minutes = String.valueOf((dur % 3600000) / 60000);
        //-->  uint(hrs) = (duration / 3600,000) to convert the uints to hours if present above the value 3600,000 & if its below then it would be decimal & therefore its a partial hour(immature) not fully mature
        String hours= String.valueOf(dur/3600000);

        //or
//        long dur = playRecord.getDuration()/ 1000; //convert it into seconds
//        String seconds = String.valueOf((dur % 60)); // get the number of whats before 60 secs
//        String minutes = String.valueOf((dur % 3600) / 60); //get the number of whats before 3600 secs(1 hr) & convert it into hrs
//        String hours= String.valueOf(dur/3600);//get the hrs & take off points of percision(decimals)

        //or
//        long dur = playRecord.getCurrentPosition();
            //todo dur/1000 to convert ms to seconds before setting its limit (60 seconds)
//        String seconds = String.valueOf(((dur/1000) % 60));//todo get the number that is below a minute & convert it from millisec to sec
        //todo dur/60*1000 to convert ms to minutes before setting its limit (60 minutes)
//        String minutes = String.valueOf(((dur/ 60000) % 60));//todo get the number that is below an hour & convert it from millisec to minutes
//        String hours= String.valueOf(dur/3600000);//todo get the number that is equal to hours & convert it into hrs


        //these conditions will check for the seconds,minutes,hours Strings to see if
        //their length is 1 in letters size(i.e only one number ...i.e numbers below 9 ) --> it will assign "0" to the expression,so for instance it would be "0"+9= 09 in reality
        if ( seconds.length() == 1 ){
            seconds="0"+seconds;
        }
        if(minutes.length() == 1){
            minutes="0"+minutes;
        }
        if(hours.length() == 1){
            hours="0"+hours;
        }
        //printing the numbers up onto the screen using the regular timer format
        Duration.setText(hours+":"+minutes + ":" + seconds);

    }


    @Override
    public void getCurrentProgressOfPlayMedia() {

        //explanations are in todo getDurationOfPlayMedia() method
        long dur = playRecord.getCurrentPosition()/ 1000; //convert it into seconds
        String seconds = String.valueOf((dur % 60)); // get the number of whats before 60 secs
        String minutes = String.valueOf((dur % 3600) / 60); //get the number of whats before 3600 secs(1 hr) & convert it into hrs
        String hours= String.valueOf(dur/3600);//get the hrs & take off points of percision(decimals)

        if ( seconds.length() == 1 ){
            seconds="0"+seconds;
        }
        if(minutes.length() == 1){
            minutes="0"+minutes;
        }
        if(hours.length() == 1){
            hours="0"+hours;
        }
        CurrentPositionOfMedia.setText(hours+":"+minutes + ":" + seconds);
    }



    @Override
    public  void Handle_Record_Duration(){
        record_duration_txt=findViewById(R.id.recordduration);
        showRecordComponent();

        //Thread runs on the UI
        EditPaneActivity.this.runOnUiThread(new Runnable() {

            public void run() {
                if ( record != null ){
                    try {
                        recordSeconds++;
                         recordSecondsString = String.valueOf((recordSeconds % 60));
                        //-->  uint(minutes) = (duration % (its limit converted from seconds  (3600 as its the begining of hrs))  / Conversion constant(60 for mins )
                         recordMinutesString = String.valueOf((recordSeconds % 3600) / 60);
                        //-->  uint(hrs) = (duration / 3600) to convert the uints(seconds) to hours if present above the value 3600 & if its below then it would be decimal
                        // & therefore its a partial hour(immature) not fully mature so hours counter would be ZERO IN THIS CASE
                         recordHoursString= String.valueOf(recordSeconds/3600);

                         if(recordSecondsString.length() == 1){
                             recordSecondsString="0"+recordSecondsString;
                         }
                         if(recordMinutesString.length() == 1){
                             recordMinutesString="0"+recordMinutesString;
                         }

                         if(recordHoursString.length() == 1){
                             recordHoursString="0"+recordHoursString;
                         }

                        handleRecordText_Notification = recordHoursString + ":" + recordMinutesString + ":" + recordSecondsString;
                        record_duration_txt.setText(handleRecordText_Notification);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                handlerForRecordDuration.postDelayed(this, 1000);
            }

        });
    }

    @Override
    public void DefineExistingRecording(String recordName) {
        playRecord = new MediaPlayer();
        try {

            playRecord.setDataSource(recordName);
            playRecord.prepare();
            Toast.makeText(getApplicationContext(), "Record Found For this Note", Toast.LENGTH_LONG).show();
            PAUSE_VALUE = 1;



            FloatingActionButton deleteRecordBtn=findViewById(R.id.deleteRecord);
            deleteRecordBtn.setEnabled(true);

            FloatingActionButton pauseMediaBtn=findViewById(R.id.playPause);
            pauseMediaBtn.setEnabled(true);

            FloatingActionButton pauseRecordBtn=findViewById(R.id.PauseRecord);
            pauseRecordBtn.setEnabled(false);

        } catch (Exception e) {
            e.printStackTrace();

            Toast.makeText(getApplicationContext(), "No Recordings for this Note,Yet", Toast.LENGTH_LONG).show();


            FloatingActionButton deleteRecordBtn=findViewById(R.id.deleteRecord);
            deleteRecordBtn.setEnabled(false);

            FloatingActionButton pauseMediaBtn=findViewById(R.id.playPause);
            pauseMediaBtn.setEnabled(false);

            FloatingActionButton pauseRecordBtn=findViewById(R.id.PauseRecord);
            pauseRecordBtn.setEnabled(false);

        }
    }





    //FAB buttons Action Listener
    @Override
    public void RecordBtn(View v) {
        try {
            recordStop = findViewById(R.id.Recordbtn);
            recordingNow=true;
            deleted=false;
            switch (VALUE_OF_RECORD) {
                case 1:
                    AccessMicPermissions();

                        DialogBoxWithRecordSave();
                        hideMediaComponents();
                        VALUE_OF_RECORD = 2;
                        text = "Stop";
                        recordStop.setLabelText(text);

                        recordStop.setImageDrawable(getDrawable(R.drawable.stop_recording));


                        FloatingActionButton pauseRecord = findViewById(R.id.PauseRecord);
                        pauseRecord.setEnabled(true);


                        FloatingActionButton DeleteRecord = findViewById(R.id.deleteRecord);
                        DeleteRecord.setEnabled(false);

                        FloatingActionButton playRecord = findViewById(R.id.playPause);
                        playRecord.setEnabled(false);

                        break;


                case 2:
                    stopRecording();
                    RefreshRecordingValues();
                    handlerForRecordDuration.removeCallbacksAndMessages(null);
                    hideRecordComponent();
                    VALUE_OF_RECORD = 1;
                    PAUSE_VALUE=1;
                    text = "Record";
                    recordStop.setLabelText(text);
                    recordStop.setImageDrawable(getDrawable(R.drawable.recordbtn));



                    pauseRecord=findViewById(R.id.PauseRecord);
                    pauseRecord.setEnabled(false);

                     DeleteRecord=findViewById(R.id.deleteRecord);
                    DeleteRecord.setEnabled(true);

                     playRecord=findViewById(R.id.playPause);
                    playRecord.setEnabled(true);

                    break;

            }

        } catch (Exception error) {
            error.printStackTrace();
            Snackbar.make(v, "Error Recording Lecture Check MIC Permissions", Snackbar.LENGTH_LONG).show();

        }
    }

    @Override
    public void hideRecordComponent(){
        if(record_duration_txt.getVisibility()==View.VISIBLE){
            record_duration_txt.setVisibility(View.INVISIBLE);
            Animation anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.shake);
            record_duration_txt.startAnimation(anim);
        }

    }
    @Override
    public void showRecordComponent(){
        if(record_duration_txt.getVisibility()==View.INVISIBLE){
            record_duration_txt.setVisibility(View.VISIBLE);
            Animation anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in);
            record_duration_txt.startAnimation(anim);
        }
    }

    @Override
    public void playRecordPauseBtn(View v) {
        try {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    4);
            playRecordingOrPause(v);

        } catch (Error e) {
            e.printStackTrace();
            Snackbar.make(v, "No Record For this Note Yet ", Snackbar.LENGTH_LONG).show();
        }
    }


    @Override
    public void PauseRecordBtn(View view) {
        pasueRecord = findViewById(R.id.PauseRecord);
        try {

            if(record != null){
                switch (PAUSE_VALUE) {
                    case 1:
                        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.N ){
                            record.pause();
                        }
                        pasueRecord.setLabelText("Resume");
                        Snackbar.make(view, "Pause", Snackbar.LENGTH_LONG).show();
                        handlerForRecordDuration.removeCallbacksAndMessages(null);

                        pasueRecord.setImageDrawable(getApplicationContext().getResources().getDrawable(R.drawable.play_ico));

                        PAUSE_VALUE = 2;
                        break;
                    case 2:

                        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.N ){
                            record.resume();
                        }

                        pasueRecord.setLabelText("Pause");
                        Snackbar.make(view, "Resuming", Snackbar.LENGTH_LONG).show();

                        Drawable imgPause = getApplicationContext().getResources().getDrawable(R.drawable.pause_ico);
                        pasueRecord.setImageDrawable(imgPause);
                        PAUSE_VALUE = 1;

                        record_duration_txt.setText(handleRecordText_Notification);
                        Handle_Record_Duration();
                        break;

                }
            }else{
                Snackbar.make(view, "No Recordings Running", Snackbar.LENGTH_LONG).show();

            }

        } catch (Exception error) {
            Snackbar.make(view, "No Recordings Running", Snackbar.LENGTH_LONG).show();
            PAUSE_VALUE = 2;
            error.printStackTrace();
        }
    }


    @Override
    public void savebtnAction(View view) {
        DialogBoxWithoutRecordSave();
        triggerEdit = 0;
    }


    //Txt to Speech Class made as a library
  class TxtToSpeechbtnAction implements View.OnClickListener {

        Context context;
      public TxtToSpeechbtnAction(Context context) {
          this.context=context;
      }
      @Override
      public void onClick(View v) {
          try {
              switch (SPEAK_STATE) {
                  //if the SPEAK_STATE is 0 means not working then start the text to speech survey
                  case 0:
                      //tts speech listener
                      ttsEngine = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
                          @Override
                          public void onInit(int status) {
                              if ( status == TextToSpeech.SUCCESS ){
                                  //tts bot language
                                  int result = ttsEngine.setLanguage(Locale.UK);

                                  //check if the language isnot supported display a message in the LogCat for not found stuff
                                  if ( result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED ){
                                      Log.e("TTS", "Bad Format");
                                  } else {
                                      //tts Engine on
                                      SpeakOut();
                                  }
                              }
                          }
                      });
                      //set the speak state to true or 1 means that we ve started the tts survey
                      SPEAK_STATE = 1;
                      break;
                  case 1:
                      //stop the survey &shutdown its background processes if its started & we are w/in it
                      ttsEngine.shutdown();
                      //stop the engine
                      ttsEngine.stop();
                      //set the speak state to false or 0 means that we ve stopped the tts survey
                      SPEAK_STATE = 0;
                      break;
              }
          } catch (Exception error) {
                //shutdown the survey & stop the engine if there's an Excetion
              ttsEngine.stop();
              ttsEngine.shutdown();
          }
      }
  }




      //Share Action
    @Override
    public void shareActionBtn(View v) {
            //Alert dialog to choose what to search
        AlertDialog.Builder sharedialogBuilder = new AlertDialog.Builder(this);
            //setting its message
        sharedialogBuilder.setMessage("Choose what to share :")
                  //1st btn
                .setPositiveButton(" TXT Note", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //share text note method
                        shareNoteTXT();
                    }
                })
                //second btn
                .setNegativeButton("Recorded Note", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // if the recording is brand new(as a result of the user pressing Ok in the dialogBox
                        //then okPressed will turn into true
                        //which can be handled here for the brand new recording for this note
                        //but for the old record from a note reading is fetched the recordName String from the main Activity
                        //to Share the older record
                        if ( !okPressed ){
                            shareRecord(recordName);
                        } else if ( okPressed ){
                            shareRecord(pathForRecordings);

                        }

                    }})
                //you can cancel this dialog by pressing back btn or outside on the Screen
                .setCancelable(true);
            //create that dialog
        AlertDialog sharedialog = sharedialogBuilder.create();
        //display it
        sharedialog.show();

    }


    @Override
    public void shareRecord(String file) {
        try {
            //Sharing the recorded Note
            Intent shareIntentRecord = new Intent(Intent.ACTION_SEND);
            shareIntentRecord.setType("audio/mp3");
            shareIntentRecord.putExtra(Intent.EXTRA_STREAM, Uri.parse(file));
            shareIntentRecord.putExtra(Intent.EXTRA_SUBJECT, "Share Record");
            startActivity(Intent.createChooser(shareIntentRecord, "Share Record"));
        } catch (NullPointerException error) {
            Toast.makeText(getApplicationContext(), "No Record To Declare", Toast.LENGTH_LONG).show();
            error.printStackTrace();
        } catch (IllegalStateException error2) {
            Toast.makeText(getApplicationContext(), "Unknown Error", Toast.LENGTH_SHORT).show();
            error2.printStackTrace();
        }
    }

    @Override
    public void shareNoteTXT() {

       try{
            //SHaring the Note Text>>>>
            Intent shareIntentNote = new Intent(Intent.ACTION_SEND);
            shareIntentNote.setType("text/plain");
            shareIntentNote.putExtra(Intent.EXTRA_SUBJECT, "Share Note");
            shareIntentNote.putExtra(Intent.EXTRA_TEXT, String.valueOf(Html.fromHtml(ed.getHtml())));
            startActivity(Intent.createChooser(shareIntentNote, "Share File"));
        }catch (Exception error){
           error.printStackTrace();
            Toast.makeText(getApplicationContext(),"Cannot Share Empty message !",Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void SpeakOut() {

        try {
            ttsEngine.speak(String.valueOf(Html.fromHtml(ed.getHtml())), TextToSpeech.QUEUE_FLUSH, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            playRecord.stop();
            playRecord.release();
            ttsEngine.stop();
            ttsEngine.shutdown();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }




    @Override
    public void update() {

        EditPaneActivity.this.runOnUiThread(new Runnable() {

            public void run() {
                if ( playRecord != null ){
                    try {
                        MediaSeekbar.setMax(playRecord.getDuration() / 1000);
                        int currentPosition = playRecord.getCurrentPosition() / 1000;
                        MediaSeekbar.setProgress(currentPosition);


                        //Add SeekBar Listener
                        MediaSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                            @Override
                            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                                if ( playRecord != null && fromUser ){
                                    playRecord.seekTo(progress * 1000);
                                    getCurrentProgressOfPlayMedia();
                                }
                            }

                            @Override
                            public void onStartTrackingTouch(SeekBar seekBar) {

                            }

                            @Override
                            public void onStopTrackingTouch(SeekBar seekBar) {

                            }
                        });
                        getCurrentProgressOfPlayMedia();
                    } catch (Exception e) {
                        hideMediaComponents();
                        e.printStackTrace();
                    }
                }
                handler.postDelayed(this, 1000);
            }

        });
    }


    @Override
    public void showMediaComponents() {
        //to refresh the duration value

        if ( playRecord != null ){
            Duration.setVisibility(View.VISIBLE);

            CurrentPositionOfMedia.setVisibility(View.VISIBLE);

            getDurationOfPlayMedia_ForShowMediaUpdate();
            if ( MediaSeekbar.getVisibility() == View.INVISIBLE ){
                MediaSeekbar.setVisibility(View.VISIBLE);

                //use animation w/ seekbar
                Animation anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.scale);
                MediaSeekbar.startAnimation(anim);
            }
        }else{
             hideMediaComponents();
        }
    }


    @Override
    public void getDurationOfPlayMedia_ForShowMediaUpdate() {

        String out = "";
        long dur = playRecord.getDuration();
        String seconds = String.valueOf((dur % 60000) / 1000);

        String minutes = String.valueOf(dur / 60000);
        out = minutes + ":" + seconds;
        if ( seconds.length() == 1 ){
            Duration.setText(String.format("0%s:0%s", minutes, seconds));
        } else {
            Duration.setText(String.format("0%s:%s", minutes, seconds));
        }

    }


    @Override
    public void hideMediaComponents() {
        try {
            MediaSeekbar = findViewById(R.id.MediaSeekBar);
            Duration = findViewById(R.id.Duration);
            CurrentPositionOfMedia = findViewById(R.id.CurrentProgress);

            MediaSeekbar.setVisibility(View.INVISIBLE);
            Duration.setVisibility(View.INVISIBLE);
            CurrentPositionOfMedia.setVisibility(View.INVISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }






    @Override
    public void searchWordBtn(View v){
        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);
        final LayoutInflater inflater = this.getLayoutInflater();
        final View layout = inflater.inflate(R.layout.search_aword, null);
        final EditText searchaWord=layout.findViewById(R.id.searchaWord);
        Button searchwordBtn = layout.findViewById(R.id.searchWordDialogBox);
        Button cancelbtn = layout.findViewById(R.id.cancelWordDialogBox);
        builder.setView(layout);


        searchwordBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    d.dismiss();

                    final ProgressDialog progress= ProgressDialog.show(v.getContext(),"Wait..","Searching Word");



                    CountDownTimer ctd=new CountDownTimer(2000,1200) {
                        @Override
                        public void onTick(long millisUntilFinished) {

                        }


                        @Override
                        public void onFinish() {

                            String newText = searchaWord.getText().toString();

                            if (! newText.isEmpty() ){
                                String value = ed.getHtml().toString();



                                String valueDeplete = value.replace(value,



                                                "<head>" +
                                                "<title>Syntax Highlight</title>" +
                                                "<script type=\"text/javascript\" src=\"https://cdnjs.cloudflare.com/ajax/libs/ace/1.2.8/ace.js\">" +

                                                "</script>" +
                                                "<style type=\"text/css\">" +
                                                "#codeEditor{" +
                                                "height: 200px;" +
                                                "width: 200px;" +

                                                        "}" +
                                                "</style>" +
                                                "</head>" +

                                                "<body>" +
                                                "<div id=\"codeEditor\">" +
                                                "public static void" +
                                                "</div>" +

                                                "<script type=\"text/javascript\">" +
                                                "var e=ace.edit(\"codeEditor\");" +
                                                "e.getSession().setMode(\"ace/mode/javascript\");" +
                                                "e.setTheme(\"ace/theme/git\");" +
                                                "</script>" +
                                                "</body>"
                                               );
                                Toast.makeText(getApplicationContext(), value, Toast.LENGTH_LONG).show();


                                ed.setHtml(valueDeplete);


                                progress.dismiss();


                            }else{
                                Toast.makeText(getApplicationContext(),"Nothing's Found",Toast.LENGTH_LONG).show();
                                progress.dismiss();
                            }
                        }
                    }.start();


                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });



        builder.setCancelable(true);
        d = builder.create();
        d.getWindow().setGravity(Gravity.BOTTOM);
        d.getWindow().getAttributes().windowAnimations=R.style.DialogAnimation1;


        d.show();


    }

    @Override
    public void Listener_For_TextColor(View view){
            textcolor=view.getTag().toString();
    }

    @Override
    public void Listener_For_SpanColor(View view){
            spancolor=view.getTag().toString();
    }


    String textFormat="plaintext";

    public void changeFormat(View view){
        textFormat=view.getTag().toString();
    }




    public void Dismiss_Dialog_Box(final AlertDialog dialog){
        CountDownTimer ctd=new CountDownTimer(1000,100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                dialog.dismiss();
            }
        }.start();

    }

    //separate Record Eraser
    @Override
    public void Delete_Record(View view){
            try {
                final View[] view2 = new View[1];
                AlertDialog.Builder AB=new AlertDialog.Builder(this);
                LayoutInflater inflate=this.getLayoutInflater();
                 View DeleteRecordABViewlayout=inflate.inflate(R.layout.custom_delete_record,null);
                AB.setView(DeleteRecordABViewlayout);

                final AlertDialog dialogBox=AB.create();
                final Button delete=DeleteRecordABViewlayout.findViewById(R.id.deleteBtn);
                final Button cancel=DeleteRecordABViewlayout.findViewById(R.id.cancelBtn);

                delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        try {


                            File recordFile = new File(recorded_for_first_time==1?pathForRecordings:recordName);
                            if(recordFile.exists()){


                                recordFile.delete();
                                deleted=true;
                                //becasue there might be a malicious fail to hide those components if they arenot really present ,so we can catch those errors seperatly to prevent failure of deletion

                                    playRecord.stop();
                                    playRecord.release();
                                    hideMediaComponents();
                                    hideRecordComponent();


                                stopSimulate=false;
                                Snackbar.make(v,  " Record is deleted Successfully", Snackbar.LENGTH_SHORT).show();

                                FloatingActionButton pauseRecord=findViewById(R.id.PauseRecord);
                                pauseRecord.setEnabled(false);


                                FloatingActionButton DeleteRecord=findViewById(R.id.deleteRecord);
                                DeleteRecord.setEnabled(false);

                                FloatingActionButton playRecord=findViewById(R.id.playPause);
                                playRecord.setEnabled(false);

                            }

                            Dismiss_Dialog_Box(dialogBox);


                        }catch (Exception e){

                            Snackbar.make(v,"No Record found", Snackbar.LENGTH_SHORT).show();

                            Dismiss_Dialog_Box(dialogBox);

                        }


                    }
                });


                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            dialogBox.dismiss();
                    }
                });


                Objects.requireNonNull( dialogBox.getWindow() ).getAttributes().windowAnimations=R.style.DialogAnimation3;
                dialogBox.show();

            }catch (Exception error){

                error.printStackTrace();

            }
    }


    public static class CheckTodoListCLass implements  CompoundButton.OnCheckedChangeListener {
        RecyclerView.Adapter todoNote_adapter;
        int position;

        CheckTodoListCLass(RecyclerView.Adapter todoNote_adapter, int position) {
                this.todoNote_adapter=todoNote_adapter;
                this.position=position;
        }


        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(!isChecked){
                    buttonView.setPaintFlags(Paint.LINEAR_TEXT_FLAG);
                    buttonView.setChecked(false);
                    save_state(App.getContext().getFilesDir() +  "/SPRecordings/todoLists/"+fileName+"/"+listTodos.get(position),false);
                }else {
                    buttonView.setPaintFlags(Paint.STRIKE_THRU_TEXT_FLAG);
                    buttonView.setChecked(true);
                    save_state(App.getContext().getFilesDir() +  "/SPRecordings/todoLists/"+fileName+"/"+listTodos.get(position),true);
                }
        }

        void save_state(String file, boolean state){
            try{
                BufferedWriter bufferedWriter=new BufferedWriter(new FileWriter(new File(file)));
                bufferedWriter.write(String.valueOf(state));
                bufferedWriter.close();
            }catch (Exception e){
                e.printStackTrace();
            }

        }
    }
}