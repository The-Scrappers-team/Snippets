package com.scrappers.notepadsnippet;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.Toast;

import java.io.File;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import static com.scrappers.notepadsnippet.App.getContext;
import static com.scrappers.notepadsnippet.MainActivity.fileName;

public class Paint extends AppCompatActivity {

     static PaintView paintView;
      static  FrameLayout contolframe;
      static Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paint);
        paintView=findViewById(R.id.canvas);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        paintView.init(metrics,getApplicationContext().getFilesDir()+ "/" + "SPRecordings" + "/"+fileName+".png");
        show_Paint_controllers();
        context=getApplicationContext();
    }
   private void show_Paint_controllers() {
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
//        fm.setCustomAnimations(R.anim.fab_slide_in_from_left,R.anim.fab_slide_in_from_right);
        PaintControls paintControls=new PaintControls();
        //show the current fragment in that frameLayout Container
        fm.replace(R.id.PaintControllers, paintControls);
        //apply Changes
        fm.commit();
       contolframe = findViewById(R.id.PaintControllers);
       contolframe.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //save the paint to a file
        paintView.save(new File(getContext().getFilesDir() + "/" + "SPRecordings"+"/"+fileName+".png"));
    }

    public void endSession() {
        finish();
    }
    public void openController(View view) {
        contolframe.setVisibility(View.VISIBLE);
    }


    public static class PaintControls extends Fragment {

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            // Inflate the layout for this fragment
            View view=inflater.inflate(R.layout.fragment_paint_controls, container, false);

            //text color
            add_Listener(R.id.rubber,Color.WHITE,view);
            add_Listener(R.id.black,Color.BLACK,view);
            add_Listener(R.id.blue,Color.BLUE,view);

            //text style
            Button emboss=view.findViewById(R.id.emboss);
            emboss.setOnClickListener(v ->paintView.emboss());
            Button normal=view.findViewById(R.id.normal);
            normal.setOnClickListener(v -> paintView.normal());
            Button blur=view.findViewById(R.id.blur);
            blur.setOnClickListener(v -> paintView.blur());

            //clear All
            Button clearAll=view.findViewById(R.id.clearAll);
            clearAll.setOnClickListener(v -> paintView.clearAll());

            //save progress
            Button savePaint=view.findViewById(R.id.save);
            savePaint.setOnClickListener(v -> {
                paintView.save(new File(getContext().getFilesDir() + "/" + "SPRecordings" + "/" + fileName + ".png"));
                Toast.makeText(getContext(),"Saved Successfully",Toast.LENGTH_LONG).show();
            });

            //dismiss
            Button dismiss=view.findViewById(R.id.dismiss);
            dismiss.setOnClickListener(v ->contolframe.setVisibility(View.INVISIBLE));

            //stroke controller
            SeekBar strokecontrol=view.findViewById(R.id.strokeControl);
            strokecontrol.setProgress(paintView.getStrokeWidth());
            strokecontrol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if(fromUser){
                        paintView.setStrokeWidth(progress);
                    }
                }


                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });

//            //quit
//            Button quit=view.findViewById(R.id.quit);
//            quit.setOnClickListener(v -> {
//                Paint paint=new Paint();
//                paint.finish();
//            });


            return view;
        }

        private void add_Listener(int id,int color,View view) {
            ImageButton btn=view.findViewById(id);
            btn.setOnClickListener(v -> {
                paintView.setCurrentColor(color);
            });
        }

    }


}
