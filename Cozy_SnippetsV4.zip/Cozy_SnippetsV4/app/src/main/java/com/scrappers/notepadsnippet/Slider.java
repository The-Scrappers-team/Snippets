package com.scrappers.notepadsnippet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import static com.scrappers.notepadsnippet.Slider_Adapter.slide_images;


public class Slider extends AppCompatActivity {

    //Slider Adpater
    private ViewPager SlideViewPager;
    private LinearLayout DotsLayout;
    private TextView[] DotsOnTxtView;
    private Slider_Adapter slider_adapter;
    private Button finishBtn;
    static boolean firstStart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slider);
        //to open the activity for the 1st time only
        SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);
        firstStart = prefs.getBoolean("firstStart", true);
        
        //StatsBar Coloring for this Activit
        getWindow().setStatusBarColor(getResources().getColor(R.color.morning));



        //check if its not really the first start -> finish & start the MAinActivity
        if ( !firstStart ){
            startActivity(new Intent(this, MainActivity.class));
            finish();
        } else {
            //if its opened for the 1st time
            //slidelayout
            SlideViewPager = (ViewPager) findViewById(R.id.viewpageslide);
            //linear layout to addView(textviews have html code &#8226 meaning a dot) so we add 3 dots using a for loop check it below
            DotsLayout = (LinearLayout) findViewById(R.id.dots);
            //custom slider adapter instance/obj
            slider_adapter = new Slider_Adapter(this);
            //setting the adapter for that viewPager
            SlideViewPager.setAdapter(slider_adapter);
            //add the dots as textviews to the current LinearLayout that is predefined in activity_slider.xml file
            addDotsIndicator(slide_images.length);
            //add listener
            SlideViewPager.addOnPageChangeListener(new Listener_For_Pages());

            finishBtn = findViewById(R.id.finishbtn);
            finishBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    finish();
                    //changing the SharedPreferences configuration
                    SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    //after starting the first time --> it will not be a first start ..because firstStart is settled to false
                    editor.putBoolean("firstStart", false);
                    //then apply the preferences changes
                    editor.apply();
                }
            });

        }
    }

    public void addDotsIndicator(int NUMBER_OF_DOTS) {

        //define a textview array given its Length the parameter -->NUMBER_OF_DOTS
        DotsOnTxtView = new TextView[NUMBER_OF_DOTS];

        //add dots from zero to NUMBER_OF_DOTS using their HTML code &#8226 & setting their size to 35
            for (int i = 0; i <= DotsOnTxtView.length-1; i++) {
                DotsOnTxtView[i] = new TextView(this);
                DotsOnTxtView[i].setText(Html.fromHtml("&#8226"));
                DotsOnTxtView[i].setTextSize(35);
                //set the first dot to white at the beginning before reaching the PageChanger Listener
                if(i==0){
                    DotsOnTxtView[i].setTextColor(getResources().getColor(R.color.white));

                }else{
                    DotsOnTxtView[i].setTextColor(getResources().getColor(R.color.transparent_white));
                }
                //add each dot the LinearLayout DotsLayout predefined in activity_slider.xml file
                DotsLayout.addView(DotsOnTxtView[i]);
            }


    }



    public void turn_All_Dots_To_Transparent_White(){
        //for loop iterates over all dots beginning from zero till NUMBER_OF_DOTS which analogs  DotsOnTxtView.length-1
        for(int n=0;n<=DotsOnTxtView.length-1;++n){
             //& sets their color to transparent_white according to their position
            DotsOnTxtView[n].setTextColor(getResources().getColor(R.color.transparent_white));
        }

    }




    //Listener class for the ViewPager 
        class Listener_For_Pages implements ViewPager.OnPageChangeListener{

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) { }

        @Override
        public void onPageSelected(int position) {
            //first of all set all dot colors to Transparent white
            turn_All_Dots_To_Transparent_White();
            //then set the current positioned dot to white color  
            DotsOnTxtView[position].setTextColor(getResources().getColor(R.color.white));
            
            //now if you have reached the end of pages then set the finish btn to visible
                //but if you ve returned back then set it to Invisible
            if(position==DotsOnTxtView.length-1){
                finishBtn.setVisibility(View.VISIBLE);
            }else{
                finishBtn.setVisibility(View.INVISIBLE);
            }

        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };
}
