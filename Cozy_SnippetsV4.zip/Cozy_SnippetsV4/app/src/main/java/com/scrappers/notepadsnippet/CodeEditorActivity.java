package com.scrappers.notepadsnippet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CodeEditorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_editor);
    }

}
