package com.scrappers.notepadsnippet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import static com.scrappers.notepadsnippet.EditPaneActivity.COLOR_PANEL_FOR;
import static com.scrappers.notepadsnippet.EditPaneActivity.ed;
import static com.scrappers.notepadsnippet.EditPaneActivity.frameLayout;

public class ColorPanel extends Fragment {
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        View view = inflater.inflate(
                COLOR_PANEL_FOR.equals("textcolor")?(R.layout.text_color_chooser):(R.layout.highlight_color_chooser), container, false);

//        //assigning IDs for those  btns from the current inflated View



        try {
            switch (COLOR_PANEL_FOR) {
                case "highlightcolor":
                    listeners_For_highlight_pane(view);
                    break;
                case "textcolor":
                    listeners_For_txtcolor_pane(view);

                    break;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        ImageView imageView=view.findViewById(R.id.close_highL);
        imageView.setOnClickListener(v -> frameLayout.setVisibility(View.INVISIBLE));


        return view;
        //or
//        return inflater.inflate(R.layout.text_color_chooser, container, false);
    }

    private void listeners_For_txtcolor_pane(View view) {
        final ImageButton red = view.findViewById(R.id.red_colorChooser);

        red.setOnClickListener(v -> ed.setTextColor(getResources().getColor(R.color.text_red_a400)));


        final ImageButton green = view.findViewById(R.id.green_colorChooser);

        green.setOnClickListener(v -> ed.setTextColor(getResources().getColor(R.color.text_green_a400)));

        final ImageButton blue = view.findViewById(R.id.blue_colorChooser);

        blue.setOnClickListener(v -> ed.setTextColor(getResources().getColor(R.color.text_blue_a400)));

        final ImageButton yellow = view.findViewById(R.id.yellow_colorChooser);

        yellow.setOnClickListener(v -> ed.setTextColor(getResources().getColor(R.color.text_yellow_a400)));

        final ImageButton black = view.findViewById(R.id.black_colorChooser);

        black.setOnClickListener(v -> ed.setTextColor(getResources().getColor(R.color.dark_3)));


        final ImageButton white = view.findViewById(R.id.white_colorChooser);

        white.setOnClickListener(v -> ed.setTextColor(getResources().getColor(R.color.white_e)));

        final ImageButton orange = view.findViewById(R.id.orange_colorChooser);

        orange.setOnClickListener(v -> ed.setTextColor(getResources().getColor(R.color.text_highL_orange)));
    }








    private void listeners_For_highlight_pane(View view) {
        final ImageButton yellow = view.findViewById(R.id.highlight_yellow);

        yellow.setOnClickListener(v -> ed.setTextBackgroundColor(getResources().getColor(R.color.text_highL_yellow_default)));

        final ImageButton red = view.findViewById(R.id.rose_colorChooser);

        red.setOnClickListener(v -> ed.setTextBackgroundColor(getResources().getColor(R.color.text_highL_red)));


        final ImageButton green = view.findViewById(R.id.green2_colorChooser);

        green.setOnClickListener(v -> ed.setTextBackgroundColor(getResources().getColor(R.color.text_highL_green)));

        final ImageButton blue = view.findViewById(R.id.lightblue_colorChooser);

        blue.setOnClickListener(v -> ed.setTextBackgroundColor(getResources().getColor(R.color.text_highL_blue)));
        final ImageButton orange = view.findViewById(R.id.orange2_colorChooser);

        orange.setOnClickListener(v -> ed.setTextBackgroundColor(getResources().getColor(R.color.text_highL_orange)));
        final ImageButton white = view.findViewById(R.id.white_highL_colorChooser);

        white.setOnClickListener(v -> ed.setTextBackgroundColor(getResources().getColor(R.color.fade_white)));

        final ImageButton black = view.findViewById(R.id.black2_colorChooser);

        black.setOnClickListener(v -> ed.setTextBackgroundColor(getResources().getColor(R.color.colorAccent)));

        final ImageButton cornysilk = view.findViewById(R.id.corny_colorChooser);

        cornysilk.setOnClickListener(v -> ed.setTextBackgroundColor(getResources().getColor(R.color.cornysilk)));

    }



    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
}
