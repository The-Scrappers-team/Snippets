package com.scrappers.notepadsnippet;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import static com.scrappers.notepadsnippet.MainActivity.fileName;

public class TodoNote_Adapter extends Adapter<TodoNote_Adapter.ViewHolderClass> {

    private ArrayList<String> checkboxesTitles;


    TodoNote_Adapter(ArrayList<String> checkboxesTitles){
        this.checkboxesTitles=checkboxesTitles;
    }
    @NonNull
    @Override
    public ViewHolderClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolderClass(LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_todolist_adapter, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderClass holder, int position) {
        holder.checkBox.setText(checkboxesTitles.get(position));
        holder.checkBox.setChecked(read(App.getContext().getFilesDir() +  "/SPRecordings/todoLists/"+fileName+"/"+checkboxesTitles.get(position)));
        holder.checkBox.setPaintFlags( (!read(App.getContext().getFilesDir() + "/SPRecordings/todoLists/" + fileName + "/" + checkboxesTitles.get(position)))?
        (Paint.LINEAR_TEXT_FLAG ): (Paint.STRIKE_THRU_TEXT_FLAG));

        holder.deletebtn.setOnClickListener(new EditPaneActivity.DeleteTodoListCLass(this,position));
        holder.checkBox.setOnCheckedChangeListener(new EditPaneActivity.CheckTodoListCLass(this,position));

    }

    private Boolean read(String file){
        try{
            BufferedReader br=new BufferedReader(new FileReader(file));
            return Boolean.parseBoolean(br.readLine());
        }catch (Exception e){
            e.printStackTrace();
            //as a default value
            return false;
        }
    }

    @Override
    public int getItemCount() {
        return checkboxesTitles.size();
    }

    static class ViewHolderClass extends RecyclerView.ViewHolder {
        CheckBox checkBox;
        AppCompatImageButton deletebtn;
        ViewHolderClass(@NonNull View itemView) {
            super(itemView);
            checkBox=itemView.findViewById(R.id.checkbox_list);
            deletebtn=itemView.findViewById(R.id.deleteTodoNote);

        }
    }
}


