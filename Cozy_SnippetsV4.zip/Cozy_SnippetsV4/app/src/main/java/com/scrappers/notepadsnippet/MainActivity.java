package com.scrappers.notepadsnippet;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SearchView;
import android.widget.Toast;
import com.baoyz.widget.PullRefreshLayout;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import io.github.douglasjunior.androidSimpleTooltip.ArrowDrawable;
import io.github.douglasjunior.androidSimpleTooltip.SimpleTooltip;

import static android.os.Environment.getExternalStorageDirectory;
import static android.os.Environment.getExternalStorageState;
import static com.scrappers.notepadsnippet.Slider.firstStart;


interface Adapter_Related{

    void Refresh();
    void defineAdapter(ArrayList<String> mainText,ArrayList<String> subText);
    void addnewNote(View view);
    void ChangeGridBtn(View view);
    void ChangeColumnsViewData();
    void CheckColumnsViewData();
}

interface Search_View_Related{
    void SearchView();
}

interface Three_Dot_Btn_Related{
    void settingsAlert();
    void setting(View view);
}

interface Stoarge_Related{
    void readTextFiles(String path);
    void fetch_FileNames(String path);
    void WriteExternalStoargePermission();
    void Make_Expansion_Dirs();
    void writeNumOfColumns(int n);
    void readNumOfColumns();
}


public class MainActivity extends AppCompatActivity implements Adapter_Related,
        Stoarge_Related,
        Search_View_Related,
        Three_Dot_Btn_Related {


    //Attributes/Fields/Vars/Objects
    CustomListAdapter lsAdapter;
    ArrayList<String> mainTitle = new ArrayList<>();
    ArrayList<String> subTitle = new ArrayList<>();
    GridView lsview;

    static int triggerEdit = 0;
    static String fileName;
    static String full_path;
    static String recordName;
    static SearchView srch;
    int numOfColumns = 0;
    ArrayAdapter<String> adapter;
    static String finalOutText;
    public static int importPosition = 0;

    //Theme Attributes/Fields/vars
    public static String Theme = "";
    public static String fileForTheme = "";
    static int NumberofNotes;

    //Theme Attributes/Fields/vars
    public static String fingerprint = "";
    public static String fileForFingerPrint = "";

    public static boolean FINGERPRINT_TRANSACTION = false;
    public static boolean DISABLE_FINGERPRINT = false;
    //Renaming note AlertDialog attribute
    AlertDialog renameAlertdialog;

    int shift = 0;
    static boolean NoMoreTutorials = true;



    public SimpleTooltip.Builder showToolTipWindow(View view, int ArrowDirection, String message) {
        if ( NoMoreTutorials ){
            SimpleTooltip.Builder tooltip = new SimpleTooltip.Builder(this);
            if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ){
                tooltip.anchorView(view)
                        .text(message)
                        .gravity(Gravity.END)
                        .arrowDirection(ArrowDirection)
                        .dismissOnOutsideTouch(true)
                        .animated(true)
                        .arrowColor(getResources().getColor(R.color.fab_red_color))
                        .transparentOverlay(false)
                        .textColor(getColor(R.color.white))
                        .backgroundColor(getResources().getColor(R.color.fab_red_color))
                        .onDismissListener(new SimpleTooltip.OnDismissListener() {
                            @Override
                            public void onDismiss(SimpleTooltip tooltip) {
                                tooltip.dismiss();
                                ++shift;
                                switch (shift) {
                                    case 1:
                                        tooltip.dismiss();
                                        showToolTipWindow(findViewById(R.id.settings), ArrowDrawable.RIGHT, "Dashboard");
                                        break;
                                    case 2:
                                        tooltip.dismiss();
                                        showToolTipWindow(findViewById(R.id.search_bar), ArrowDrawable.LEFT, "Search your note");

                                        break;
                                    case 3:
                                        tooltip.dismiss();
                                        showToolTipWindow(findViewById(R.id.listFiles), ArrowDrawable.LEFT, "Your Notes");
                                        break;
                                    default:
                                        tooltip.dismiss();
                                        break;
                                }
                            }
                        })
                        .build()
                        .show();
            }
            return tooltip;

        } else {
            return null;
        }
    }





    //Methods/Functions
    @Override
    public void onCreate(Bundle savedInstanceState) {
        //accessing permissions write/read files from the Internal Storage
        WriteExternalStoargePermission();
        //Reading themes database
        ReadTheme();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Condition containing an operand operation where
            //FINGERPRINT_TRANSACTION is to:
        //DISABLE_FINGERPRINT is to:
        if(FINGERPRINT_TRANSACTION==false && DISABLE_FINGERPRINT==false){
            ReadFingerPrint();
        }
        //reading fingerprint database to see if its enabled or not
//        ReadFingerPrint();
        //check files in the Application Cache & Data Directory & fetch & Display Them onto my ArrayAdapter of my ListView/RecycleViewer
        fetch_FileNames(getApplicationContext().getFilesDir() + "/SPRecordings/Notes");
        //defining the ArrayAdapter / subtitle & Maintitle
        defineAdapter(mainTitle, subTitle);
        //checking for columns data of gridview
        CheckColumnsViewData();
        //Running the SearchView & its Listeners + Animations
        SearchView();

        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ){
            startForegroundService(new Intent(this, PushNotifications.class));
            ComponentName receiver = new ComponentName(getApplicationContext(), PushNotifications.class);
            PackageManager pm = this.getPackageManager();

            pm.setComponentEnabledSetting(receiver,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP);
        }


        if(!firstStart){

        }else {
            showToolTipWindow(findViewById(R.id.addbtn),ArrowDrawable.LEFT,"Add new Note");
        }
    }


    @Override
    public void Make_Expansion_Dirs() {
        //Make New directory for App
        File companyFile = new File(getApplicationContext().getFilesDir() + "/" + "SPRecordings");
        companyFile.mkdir();

        //Make New directory for Notes
        File TextFiles = new File(getApplicationContext().getFilesDir() + "/" + "SPRecordings/Notes");
        TextFiles.mkdir();

        //make new directory for the todoLists
        File sub_companyFile=new File(getApplicationContext().getFilesDir() +  "/SPRecordings/todoLists");
        sub_companyFile.mkdir();

        //make new directory for the paint views
        File paintDir=new File(getApplicationContext().getFilesDir() +  "/SPRecordings/paints");
        paintDir.mkdir();

        //make new directory for the adapter columns num
        File gridView_columnData=new File(getApplicationContext().getFilesDir()+"/SPRecordings/adapter_database");
        gridView_columnData.mkdir();


        //make new directory for the fingerprint db
        File fingerprintdirectory=new File(getApplicationContext().getFilesDir()+"/SPRecordings/fingerprint");
        fingerprintdirectory.mkdir();

        //make new directory for the fingerprint db
        File imagedirectory=new File(getApplicationContext().getFilesDir()+"/SPRecordings/images");
        imagedirectory.mkdir();


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        FINGERPRINT_TRANSACTION=false;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        FINGERPRINT_TRANSACTION=false;

    }

    //Reads the theme from the file directory && Applies it
    public void ReadTheme() {
        try {
            //themes directory & themes files w/ scrappers extension :->))
            fileForTheme= (getApplicationContext().getFilesDir()+ "/SPRecordings/adapter_database/" +"Theme.scrappers");
            //read themes in that file
            BufferedReader br = new BufferedReader(new FileReader(fileForTheme));
            if ( br.ready() ){
                //reading first line of that db file
                Theme = br.readLine();
                //applying themes according to the content
                if(Theme.contains("GreenTheme")){
                    setTheme(R.style.GreenTheme);
                }else if(Theme.contains("AppTheme")){
                    setTheme(R.style.AppTheme);
                }else if(Theme.contains("GrayScaleTheme")){
                    setTheme(R.style.Darky);
                }else if(Theme.contains("TitanTheme")){
                    setTheme(R.style.orangeLover);
                }else if(Theme.contains("CyanTheme")){
                    setTheme(R.style.BlueDark);
                }
                //close the BR
                br.close();
            }
            //Exception if the file isnot found --> add that bad boy :->))
        } catch (Exception error) {
            error.printStackTrace();
            //if the theme file isnot found -> add it w/ the default theme
            try {
                BufferedWriter bw = new BufferedWriter(new FileWriter(fileForTheme));
                bw.write("R.style.AppTheme");
                bw.close();

                //catching an IllegealStateException if user havenot given the access permission to Storage Yet Read/Write especially write
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void ReadFingerPrint() {
        try {
            //themes directory & themes files w/ scrappers extension :->))
            fileForFingerPrint= (getApplicationContext().getFilesDir()+ "/SPRecordings/fingerprint/" +"fingerprint.scrappers");
            //read themes in that file
            BufferedReader br = new BufferedReader(new FileReader(fileForFingerPrint));
            if ( br.ready() ){
                //reading first line of that db file
                fingerprint = br.readLine();
                //applying themes according to the content
                if(fingerprint.equals("lock")){

                    finish();
                    startActivity(new Intent(this,FingerPrint.class).addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY));

                }else if(fingerprint.equals("unlock")){


                }else{

                }
                //close the BR
                br.close();
            }
            //Exception if the file isnot found --> add that bad boy :->))
        } catch (Exception error) {
            error.printStackTrace();
            //if the theme file isnot found -> add it w/ the default theme
            try {
                BufferedWriter bw = new BufferedWriter(new FileWriter(fileForFingerPrint));
                bw.write("unlock");
                bw.close();

                //catching an IllegealStateException if user havenot given the access permission to Storage Yet Read/Write especially write
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void SearchView() {
        //Handling SearchView And SearchView Animation & Listeners
        srch = findViewById(R.id.search_bar);
        //SearchView open Listener
        srch.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //use animation w/ searchBar SearchView
                Animation anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_scale_up);
                //starting animation
                srch.startAnimation(anim);
            }
        });


        //SearchView onClose Listener
        srch.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                Animation anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_close);
                srch.startAnimation(anim);

                //Animation Listener w/ overridable methods
                anim.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                                //refresh by restarting the Application MainActivity.class
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        finish();
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });
                return true;
            }
        });


        srch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                lsview.setAdapter(adapter);
                adapter.getFilter().filter(newText);
                return false;
            }
        });

    }





    //Requesting External Storage Permissions for read/write data
    public void WriteExternalStoargePermission() {
        //accessing permissions from the AndroidManifest.xml
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                1);

            Make_Expansion_Dirs();




    }




    //setting up Refreshing Layout & its Sytle & Refresh Listener & ListView ArrayAdapter updater
    public void Refresh(){
        final PullRefreshLayout refreshLayout=findViewById(R.id.refreshLayout);
        refreshLayout.setRefreshStyle(PullRefreshLayout.STYLE_MATERIAL);
        refreshLayout.setOnRefreshListener(() -> {

             CountDownTimer synchronize=new CountDownTimer(1000,100) {
                @Override
                public void onTick(long millisUntilFinished) { }
                @Override
                public void onFinish() {
                    //redefining the adapter leads to refreshing the layout view
                    defineAdapter(mainTitle,subTitle);
                    //set refreshing state to false
                    refreshLayout.setRefreshing(false);
                    //return true for the finger print to be able to refresh the state
                    // w/o fingerprint page/activity being shown
                    FINGERPRINT_TRANSACTION=true;
                    //cancel the timer to restart the process
                    this.cancel();
                }
            }.start();
        });

    }


    //defining the ListView ArrayAdapter Method
    //-> fetching the mainTitle ArrayList data & subTitle ArrayList Data from fetch_FileNames(...) method to the ListView/RV Adapter
    public void defineAdapter(ArrayList<String> mainText, final ArrayList<String> subText) {

        //defining ListView ArrayAdapter Custom Instance/Object
        lsAdapter = new CustomListAdapter(this, mainTitle,subTitle);
        //Defining a normal/Standard ArrayAdapter Instance/Object for displaying the Search Results
        adapter=new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,mainTitle);
        //Defining ListView Instance for that Specific id
        lsview = findViewById(R.id.listFiles);
        //setting up the CustomArrayAdapter to the list view Layout
        lsview.setAdapter(lsAdapter);
        //Running the refresh layout for displaying the Refresh Bar
        Refresh();
        //Defining ListView on item click listener for handling the 2nd Activity
        //-> Handling the open of the previously Created Notes(Your already created Notes) to edit them if you wish so...
        lsview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            //Overriding an abstract method principle in java
            //-> onItemClick(....); is an abstract method(void having no body,but name & SemiColon) in OnItemClickListener() Interface
            // & in abstract class AdapterView & Must be Overridden to workout
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                //Starting the EditPaneActivity activity/Intent from this Intent(Context)
                startActivity(new Intent(getApplicationContext(), EditPaneActivity.class));
                //Transition Animation
                overridePendingTransition(R.anim.slide_in_activity,R.anim.slide_out_activity);
                //finishing/exiting this Activity
                finish();
                //Assigning fileName String(Static) to the Current Selected Note to use it in reading the data inside the note using readTextFiles(...) Methods
                //-> & using it in saving the note w/ the same Name using the sameSaveName Btn in
                //DialogBoxWithRecordSave(...)/DialogBoxWithoutRecordSave(...) Methods
                // in EditPaneActivity.java class :-))
                fileName = lsAdapter.getItem(position);



                try {
                    //reading the data of the Currently Selected Note(fileName)
                    // -> & its record File(if exists & if not -> NullPointerException -> e is handled in stack Trace)
                    readTextFiles(getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + fileName);
                    recordName = getExternalStorageDirectory() + "/SPRecordings/" + fileName
                            + ".mp3";
                    //triggerEdit is an int var -> to inform the second activity if this was a new Note or an edit for a previous Note
                    //triggerEdit=1 --> trigger an edit to a previous Note -> opens the second Activity(EditPaneActivity.java) on the data of this note
                    // -> to be able to edit it
                    //triggerEdit=0 --> trigger a new Note -> informs the secondActivity(EditPaneActivity.java) to be opened up w/ no data & no previous Name(not null)
                    triggerEdit = 1;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        //defining an AlertDialogBuilder using Builder static Class(There are other ways) to build the AlertDialog on it
        //NB(Deep Knowledge) :
        // final -> is a keyword not an access Modifier -> to make this attribute immutable(unchangeable) & to access the object builder from w/in the inner class AdapterView
        final AlertDialog.Builder builder =
                new AlertDialog.Builder(this);

        //Defining ListView on item long click listener for handling the delete Note(w/ delete all its data & record) Action
        //-> Handling the delete of the previously Created Notes(Your already created Notes)
        lsview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {


                //set The Message for that Builder(Hint!!!-> Revise getters & setters in java)
                builder.setMessage("Are you Sure you want to delete this item ?")
                        //setting the positive btn
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            //abstraction & Interfaces Applied
                            public void onClick(DialogInterface dialog, int id) {
                                try {
//                                    //declaring a file instance w/ a specific read/write  path
                                            //making a file Instance/object using File utility java class library
                                            //-> & assigning that object to a new file in the directory of the app using the name of the clicked item in that adapter
                                            File file = new File(getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + lsAdapter.getItem(position));
                                            //deleting that selected item -> leads to deleting that file in realty
                                            file.delete();
                                            //fetching the recording path for that current selected file & adding the Extension ".mp3"
                                            String pathForRecordings = getExternalStorageDirectory() + "/SPRecordings/" + lsAdapter.getItem(position)
                                                    + ".mp3";
                                            //making a new file Instance called recordFile & assigning it to have the record file Name that we ve fetched
                                            File recordFile = new File(pathForRecordings);
                                            //deleting that recording file
                                            recordFile.delete();


                                            //making a new file Instance called toDoList_File & assigning it to have the to-do List file Name that we ve fetched
                                            File toDoList_File = new File(getApplicationContext().getFilesDir() + "/SPRecordings/todoLists/" + lsAdapter.getItem(position) +"/");
                                            //deleting that toDo-List file
                                            toDoList_File.delete();

                                            //make new directory for the paint views
                                            File paintfile=new File(getApplicationContext().getFilesDir() +  "/SPRecordings/paints/"+lsAdapter.getItem(position)+".png");
                                            paintfile.delete();

                                //restarting the activity to refresh its state(ListView adapter) after deleting that file
                                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                                //finishing the previous activity to prevent activities overlapping & lags
                                finish();

                                } catch (NullPointerException e) {
                                    //printing the stackError into the Logcat(There are many other ways to do so)
                                    e.printStackTrace();
                                }

                            }
                        }).setNeutralButton("Rename", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        runRenameDialog(position);




                                    }
                                })

                        //setting up the -'ve btn to No & its onclick listener
                        //->NB(Deep Knowledge) -> its click Listener calls the d2.dismiss(); spontaneously/Automatically
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //->NB(Deep Knowledge) -> -'ve btn click Listener calls the d2.dismiss(); spontaneously/Automatically


                            }
                        })
                        //setting the cancelable() function to false -> you cannot cancel it by any action(eg:-pressing on white Surrounding screen) except the -ve btn
                        .setCancelable(false);
                //creating an AlertDialog instance and adding it to the builder that we 've configured its properties
                AlertDialog d2 = builder.create();
                //showing that dialog onto the screen
                d2.show();




                //function return word
                return true;


            }
        });


    }

    //Rename Dialog method
    public void runRenameDialog(final int position){

        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);
        final LayoutInflater inflater = this.getLayoutInflater();
        final View layout = inflater.inflate(R.layout.dialogboxlayout, null);
        Button okbtn = layout.findViewById(R.id.okBtn);
        Button cancelbtn = layout.findViewById(R.id.CancelBtn);
        final EditText newName=layout.findViewById(R.id.nameofsavefile);
        builder.setView(layout);
        // Dialog will have "Make a selection" as the title

        okbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Rename the text/note file
                File fileName=new File(getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + lsAdapter.getItem(position));
                fileName.renameTo(new File(getApplicationContext().getFilesDir() + "/SPRecordings/Notes/" + newName.getText()));


                //Rename the Associated record file
                File recordFileName=new File(getExternalStorageDirectory() + "/SPRecordings/" + lsAdapter.getItem(position)
                        + ".mp3");
                recordFileName.renameTo(new File(getExternalStorageDirectory() + "/SPRecordings/" + newName.getText()
                        + ".mp3"));


                //Rename the Associated Todo-List
                //Rename the Associated record file
                File Todo_listFileName=new File(getApplicationContext().getFilesDir() + "/SPRecordings/todoLists/" + lsAdapter.getItem(position));
                Todo_listFileName.renameTo(new File(getApplicationContext().getFilesDir() + "/SPRecordings/todoLists/" + newName.getText()));

                //make new directory for the paint views
                File paintfile=new File(getApplicationContext().getFilesDir() +  "/SPRecordings/paints/"+lsAdapter.getItem(position)+".png");
                paintfile.renameTo(new File(getApplicationContext().getFilesDir() + "/SPRecordings/paints/" + newName.getText()+".png"));
                //Dismiss that dialog after data transactions are completed
                renameAlertdialog.dismiss();
                //refresh by restarting the Application Activity
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();

            }
        });

        //cancel btn dismiss the dialog w/o data change(w/o Rename action)
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                renameAlertdialog.dismiss();
            }
        });

        builder.setCancelable(true);
        renameAlertdialog= builder.create();
        renameAlertdialog.getWindow().setGravity(Gravity.CENTER);
        renameAlertdialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation2;
        renameAlertdialog.show();


    }
    //method to read data of the selected note from the ListView adapter
    //path for the path of files -> directory + Main Name of file
    public void readTextFiles(String path) {
        //try catch to catch an I/OException if there 're no files
        try {
            //making a new BufferedReader Instance  & parsing a new FileReader instance that contains that path
            BufferedReader reader = new BufferedReader(new FileReader(path));
            //to avoid showing null results w/ attempt to open the item
            if ( !reader.ready() ){
                finalOutText = "";
                //closing the reader & don't read anything if the file isn't ready
                reader.close();
            } else {
                //reading the first Line of that file's data & giving it a separate Line
                StringBuilder outputText = new StringBuilder(reader.readLine() + "\n");
                //check if the BufferedReader be able to read more data(Lines) inside that text file
                //reading other lines(if exist) & assigning them to the same String(first Line)
                while (reader.ready()) {
                    outputText.append(reader.readLine()).append("\n");
                }
                //assigning the outputText value to the finalOutText which is a global version of the outputText
                finalOutText = outputText.toString();
                //closing the BR for saving data
                reader.close();
                //Message Display
                Toast.makeText(getApplicationContext(), "Read Successful", Toast.LENGTH_LONG).show();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    //Method Declared as public(Access Modifier/Specifier)<Visible outside the activity> -> To read fileNames from the app directory
    //& stores name in an array of Files
    // -> then adding those names to the ArrayList(mainTitle) to fetch them onto the ListView/RV adapter using the defineAdapter(...) method
    public void fetch_FileNames(String path) {
        try {
            //declaring a file instance w/ a specific read/write  path
            File[] files = new File(path).listFiles();
            //using foreach/for loop to list all files(We Prefer for loop to control the iteration purpose)
            for (int num = 0; num <= files.length - 1; ++num) {
                //adding the files to the ArrayList mainTitle to fetch them onto the lsAdapter(ArrayAdpter of listView)
                mainTitle.add(files[num].getName());
                //using java date/time utility library to call the last modification of these files shown onto the adapter
                Date d = new Date(files[num].lastModified());
                //adding the last modification date to these items onto the adapter as a subTitle Text
                subTitle.add(String.valueOf(d.toLocaleString()));

            }

            NumberofNotes=files.length+1;

        } catch (NullPointerException e) {
            //printing the stackError into the Logcat(There are many other ways to do so)
            e.printStackTrace();
        }
    }

    //method for adding a new note
    // -> has a view for the addNewNote Btn onClickListener -> called in the activity_main.xml in the onClick Tag of the addbtn floating button
    public void addnewNote(View view) {


                //starting the secondActivity(EditPaneActivity.java) from this Intent
                startActivity(new Intent(getApplicationContext(), EditPaneActivity.class));
                //Transition Animation
                overridePendingTransition(R.anim.slide_in_activity,R.anim.slide_out_activity);
                //finishing that activity to prevent overlapping of activities & errors in data write/read
                finish();
                //giving the triggerEdit a zero value -> trigger the second Activity(EditPaneActivity.java) to open a new note
                triggerEdit = 0;

    }



    //method for the custom AlertDialog that ve been made for the 3 dot btn to display the settings & the about
    public void settingsAlert() {
        //defining an alertDialog builder instance in this context
        AlertDialog.Builder builder =
                new AlertDialog.Builder(this,R.style.RoundAlertDialog);
        //defining a layout inflater instance to to inflate a view that has that custom layout w/in the inside
        //Deep:- final is a keyword -> Immutable & accessing data from an inner class (View class)
        final LayoutInflater inflater = this.getLayoutInflater();
        //defining a View instance/obj & inflating the custom layout
        final View layout = inflater.inflate(R.layout.alrtbox_items_menu, null);
        //setting that badBoy(view)to the current builder
        builder.setView(layout);


        //defining a button and fetching the btn id
        Button about = layout.findViewById(R.id.about);
        //btn OnClickListener has a parameter that has the abstract method onClick(View v); in the OnClickListener() interface in the View Class
        //Deep Knowledge:-the keyword-> new -> for creating the new instance for that Specific class & using it as a reference value in calling the abstract method onClick
        about.setOnClickListener(v -> {
            //starting the aboutActivity.class from that Intent w/o finishing that one because its an info activity so no data conflict/overlapping
            startActivity(new Intent(getApplicationContext(), aboutActivity.class));

        });
        //defining a button Instance/obj and fetching the btn id
        Button settings = layout.findViewById(R.id.settings);
        settings.setOnClickListener(v -> {
            //starting settings activity
            startActivity(new Intent(getApplicationContext(), Settings.class));
            //transition
            overridePendingTransition(R.anim.slide_up_activity,R.anim.slide_down_activity);

        });
//defining a button Instance/obj and fetching the btn id
        Button privacyPolicy = layout.findViewById(R.id.privacypolicy);
        privacyPolicy.setOnClickListener(v -> {
            Intent intent=new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://cozysnippets-notepad.flycricket.io/privacy.html"));
            startActivity(intent);
        });
        //creating an alertDialog instance and adding it to the builder
        AlertDialog alert = builder.create();
        //setting the window gravity to bottom
        alert.getWindow().setGravity(Gravity.BOTTOM);
        //running the animations on the alertDialog from styles.xml
        alert.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation1;
        //showing that alertDialog
        alert.show();
    }

    //The action Listener for the 3 dot button in the activity_main.xml
    public void setting(View view) {
        //calling the custom AlertDialog that has the 2 buttons(aboutBtn & SettingsBtn)
        settingsAlert();
    }


    // method for the action Listener for the grid btn in the activity_main.xml
    public void ChangeGridBtn(View view) {
        //method for changing the columns of the grid view according to its current state(Value)
        ChangeColumnsViewData();

    }


    //Handling GridView & Number of Columns -> writing the antagonist number
    public void writeNumOfColumns(int data) {
        try {
            //making a new BufferedWriter Instance & parsing a new FileWriter w/ the path for the number of columns
            BufferedWriter Bwriter = new BufferedWriter(new FileWriter(getApplicationContext().getFilesDir() + "/SPRecordings/adapter_database/" +
                    "column"));
            //writing data to the file
            Bwriter.write(String.valueOf(data));
            //close to save & Buffer/update cache
            Bwriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //method to read number of columns when we open the application(called w/in the ChangeColumnsViewData() method & w/in CheckColumnsViewData()
    public void readNumOfColumns() {
        try {
            //BufferedReader Instance & FileReader Parsing
            BufferedReader Breader = new BufferedReader(new FileReader(getApplicationContext().getFilesDir() + "/SPRecordings/adapter_database/" +
                    "column"));
            //reading the 1st Line  -> in a String
            String numString = Breader.readLine();
            //Converting the String into an Integer
            // -> so we can use it in setNumColumns() when we call it in the onCreate() method via the CheckColumnsViewData() method
            numOfColumns = Integer.parseInt(numString);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //method for changing the gridView Columns depending on its current State
    // ---> used in the ChangeGridBtn(View view) (gridbtn onClickListner)
    public void ChangeColumnsViewData() {
        //checking if the number of columns is 1
        // -> Then set it to 2 -> write new data -> auto update view
        if ( lsview.getNumColumns() == 1 ){
            lsview.setNumColumns(2);
            writeNumOfColumns(2);
        }

        //checking if the number of columns is 2
        // -> Then set it to 1 -> write new data -> auto update view
        else if ( lsview.getNumColumns() == 2 ){
            lsview.setNumColumns(1);
            writeNumOfColumns(1);
        }
    }

    //checking the data of the file column in SPRecordings & setting the data to that gridView
    public void CheckColumnsViewData() {
        try {
            readNumOfColumns();
            lsview.setNumColumns(numOfColumns);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}