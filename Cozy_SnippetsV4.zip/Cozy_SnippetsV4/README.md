# CozySnippets__Changed

hI 2math,

yeh this is our project 

1st of all download git plugin for linux from this site:
    https://www.atlassian.com/git/tutorials/install-git?fbclid=IwAR0bjIGHLuAq21ZUYj0MncjCZdJP66GMMTUCmiZX-zISDahL94qVIF_UW-E#linux
&& donot use github website 

2nd of all navigate to android studio
      on the titlebar use File>Settings>Version Control>Git>use the Test button to test your git plusing version OR use command:
            git --version in ur Terminal
            
3rdly Login using our github account in Android Studio>File>Settings>Version Control>GitHub


Then,when you wanna upload your app to our Repository(its basically an online directory) navigate through 
      
        In TitleBar   VCS>commit>commit button && commit your cahnges then you will be able to spread your update 
        then , to update files use VCS>git>push>push your commit not the git master 
        
        
If you want to update your files from github use VCS>Git>Comapre w/ the same Respository Version 

Thank you , call me if there's any issue :-))
